
#' make findme connection
#'
#' @return connection
#' @export
#'
#' @examples
get_app_connection <- function() {
    con <<- DBI::dbConnect(duckdb::duckdb(), dbdir = ":memory:")
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' create mock db
#'
#' @param con connection
#'
#' @return nothing
#' @export
#'
create_mock_db <- function(con) {
    DBI::dbExecute(con, "CREATE SCHEMA sandbox;")
    DBI::dbExecute(con, "CREATE SEQUENCE sandbox.emploee_id_seq START 1;")
    DBI::dbExecute(con, "CREATE SEQUENCE sandbox.employer_id_seq START 1;")

    DBI::dbExecute(con, "CREATE TABLE sandbox.employee (
	                        id int NOT NULL,
	                        name varchar(50) NOT NULL,
	                        last_name varchar(50) NOT NULL,
	                        address_line_1 varchar(100) NOT NULL,
	                        address_line_2 varchar(100) NULL,
	                        city varchar(100) NOT NULL,
	                        state varchar(100) NOT NULL,
	                        zipcode varchar(20) NOT NULL,
	                        area_code varchar(4) NOT NULL,
	                        telephone varchar(10) NOT NULL,
	                        profession int4 NOT NULL,
	                        email varchar(100) NOT NULL,
	                        username varchar(100) NOT NULL,
	                        password varchar(35) NOT NULL,
	                        CONSTRAINT pk_employee PRIMARY KEY (id),
	                        CONSTRAINT uk_telephone_zipcode UNIQUE (telephone, zipcode)
                   );")
    DBI::dbExecute(con, "CREATE TABLE sandbox.employer (
	                        id int NOT NULL,
	                        office_name varchar(50) NOT NULL,
	                        address_line_1 varchar(100) NOT NULL,
	                        address_line_2 varchar(100) NULL,
	                        city varchar(100) NOT NULL,
	                        state varchar(100) NOT NULL,
	                        zipcode varchar(20) NOT NULL,
	                        area_code varchar(4) NOT NULL,
	                        telephone varchar(10) NOT NULL,
	                        profession int4 NOT NULL,
	                        email varchar(100) NOT NULL,
	                        username varchar(100) NOT NULL,
	                        password varchar(35) NOT NULL,
	                        CONSTRAINT pk_employee PRIMARY KEY (id),
	                        CONSTRAINT uk_telephone_zipcode UNIQUE (telephone, zipcode)
                   );")
    DBI::dbExecute(con, "CREATE TABLE sandbox.profession (
	                        id int NOT NULL,
	                        name varchar(50) NOT NULL,
	                        category varchar(50) NOT NULL,
	                        CONSTRAINT pk_profession PRIMARY KEY (id)
                   );")
    DBI::dbExecute(con, "INSERT INTO sandbox.profession (
    id,
    name,
    category
    )
    VALUES
    (1, 'eye_prof1', 'Optometry'),
    (2, 'eye_prof2 ', 'Optometry'),
    (3, 'eye_prof3', 'Optometry'),
    (4, 'sceintist_data', 'Science'),
    (5, 'sceintist_ml', 'Science'),
    (6, 'sceintist_research', 'Science');")
    DBI::dbExecute(con, glue::glue("INSERT INTO sandbox.employer (
	                        id,
	                        office_name,
	                        address_line_1,
	                        address_line_2,
	                        city,
	                        state,
	                        zipcode,
	                        area_code,
	                        telephone,
	                        profession,
	                        email,
	                        username,
	                        password)
	                        VALUES
    (1, 'Office_1', '201 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234561', 1, 'abcd1@gmail.com', 'abcd1@gmail.com', '{digest::digest('foo1', 'md5', serialize = FALSE)}'),
    (2, 'Office_2', '202 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234562', 2, 'abcd2@gmail.com', 'abcd2@gmail.com', '{digest::digest('foo2', 'md5', serialize = FALSE)}'),
    (3, 'Office_3', '203 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234563', 3, 'abcd3@gmail.com', 'abcd3@gmail.com', '{digest::digest('foo3', 'md5', serialize = FALSE)}'),
    (4, 'Office_4', '204 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234564', 4, 'abcd4@gmail.com', 'abcd4@gmail.com', '{digest::digest('foo4', 'md5', serialize = FALSE)}'),
    (5, 'Office_5', '205 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234565', 5, 'abcd5@gmail.com', 'abcd5@gmail.com', '{digest::digest('foo5', 'md5', serialize = FALSE)}'),
    (6, 'Office_6', '206 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234566', 6, 'abcd6@gmail.com', 'abcd6@gmail.com', '{digest::digest('foo6', 'md5', serialize = FALSE)}');"))

    DBI::dbExecute(con, glue::glue("INSERT INTO sandbox.employee (
	                        id,
	                        name,
	                        last_name,
	                        address_line_1,
	                        address_line_2,
	                        city,
	                        state,
	                        zipcode,
	                        area_code,
	                        telephone,
	                        profession,
	                        email,
	                        username,
	                        password)
	                        VALUES
    (1, 'Nam1', 'LastNam1', '207 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234561', 1, 'abc1@gmail.com', 'abc1@gmail.com', '{digest::digest('foo1', 'md5', serialize = FALSE)}'),
    (2, 'Nam2', 'LastNam2', '208 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234562', 2, 'abc2@gmail.com', 'abc2@gmail.com', '{digest::digest('foo2', 'md5', serialize = FALSE)}'),
    (3, 'Nam3', 'LastNam3', '209 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234563', 3, 'abc3@gmail.com', 'abc3@gmail.com', '{digest::digest('foo3', 'md5', serialize = FALSE)}'),
    (4, 'Nam4', 'LastNam4', '210 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234564', 4, 'abc4@gmail.com', 'abc4@gmail.com', '{digest::digest('foo4', 'md5', serialize = FALSE)}'),
    (5, 'Nam5', 'LastNam5', '211 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234565', 5, 'abc5@gmail.com', 'abc5@gmail.com', '{digest::digest('foo5', 'md5', serialize = FALSE)}'),
    (6, 'Nam6', 'LastNam6', '212 san carlos way', '', 'Placentia', 'California', '92870', '001' ,'9491234566', 6, 'abc6@gmail.com', 'abc6@gmail.com', '{digest::digest('foo6', 'md5', serialize = FALSE)}');"))
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
open_panel_as_dialog <- function( title, panel, width = 700, height = 600,
                                  buttons = shiny::tagList(
                                      shiny::actionButton("dialog_cancel",         "Cancel"),
                                      shiny::actionButton("dialog_apply_changes",  "Apply Changes")
                                  ) ){
    smd <- as_shiny_draggable_modal_dialog(
        title = title,
        options = list(handle = '.modal-header'),

        panel,

        width  = width,
        height = height,

        footer = buttons
    )

    shiny::showModal(smd)

    return(invisible(NULL))
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
section_title <- function(title, id = NULL, size = 2) {
    assign("func", eval(parse(text = paste0("shiny::tags$h", size))))
    if (is.null(id)) {
        func(title, style = "background-color: #034580; color: #FFFFFF; padding: 5px; border: 1px solid #999; margin: 0px 10px 10px 10px;")
    } else {
        func(title, id = id, style = "background-color: #034580; color: #FFFFFF; padding: 5px; border: 1px solid #999; margin: 0px 10px 10px 10px;")
    }
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
as_shiny_draggable_modal_dialog <- function(..., options = NULL, title = NULL, width = 700, height = 600, footer = shiny::modalButton("Dismiss"), size = c("l", "s", "m"), easy_close = FALSE, fade = TRUE) {

    size <- match.arg(size)
    cls <- if (fade) { "modal fade" } else { "modal" }

    dialog <- shiny::div(
        id = "shiny-modal",
        class = cls,
        style = "border: 1px solid #777777",
        tabindex = "-1",
        `data-backdrop` = if (!easy_close) { "static" } ,
        `data-keyboard` = if (!easy_close) { "false" } ,
        shiny::div(
            class = "modal-dialog",
            class = switch(size, s = "modal-sm", m = NULL, l = "modal-lg"),
            style = sprintf("width: %spx;", width),
            shinyjqui::jqui_draggable(
                options = options,
                shiny::div(
                    class = "modal-content",
                    style = sprintf("width: %spx; height: %spx;", width, height),
                    if (!is.null(title)) {
                        shiny::div(
                            class = "modal-header",
                            style = 'background-color: #007DC3; color: #FFFFFF; padding: 7px; border-bottom: 1px solid #4e4e4e;',
                            shiny::tags$h3(class = "modal-title",  title)
                        )
                    },
                    shiny::div(
                        class = "modal-body",
                        style = sprintf("padding: 10px 0px 0px 0px; width: 100%%; height: %spx",(height-100)),
                        ...
                    ),
                    if (!is.null(footer)) {
                        shiny::div(
                            id    = "dialog_footer",
                            class = "modal-footer",
                            style = "padding: 7px; border-top: 1px solid #999;",
                            footer)
                    }
                )
            )
        ),
        shiny::tags$script("$('#shiny-modal').modal().focus();")
    )

    return(dialog)

}



#' get findame data for a give indicaiton
#'
#' @param indication indication name
#'
#' @return dataframe
#' @export
#'
#' @examples
get_input_data <- function(indication = NULL) {
  dt_raw <- try(readRDS(system.file("inst/extdata/data_combined.RDS", package = "findme")), silent = T)
  if (inherits(dt_raw, "try-error")) {
    dt_raw <- readRDS(system.file("extdata/data_combined.RDS", package = "findme"))
  }

  # all_files <- list.files("/userdata/cfdads/exploratory_data/equip/data/", full.names = T, recursive = T)
  # all_files <- all_files[grepl("Latest.parquet", all_files)]
  # dt_raw <- NULL
  # for (i in seq_len(length(all_files))) {
  #     temp_dt <- arrow::read_parquet(all_files[i], as_data_frame = T)
  #     dt_raw <- dplyr::union_all(dt_raw, temp_dt)
  # }
  if ( !is.null(indication)) {
    dt_raw <- dt_raw %>% dplyr::filter(Indication == !!indication)
  }
  return(dt_raw)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' map cords to country name convertor
#'
#' @param points points on map
#'
#' @return country name
#' @export
#'
#' @examples coords2country(points = data.frame(lon= 87.5390625, lat=66.5132604431119))
coords2country <- function(points) {
    countries_sp <- rworldmap::getMap(resolution = "low")
    points_sp <- sp::SpatialPoints(points,
                                   proj4string = sp::CRS(sp::proj4string(countries_sp)))
    indices <- sp::over(points_sp, countries_sp)
    indices$ADMIN
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' assign name to list
#'
#' @param l list object
#' @param n names
#'
#' @return named list
#' @export
#'
#' @examples set_list_names(list(1,2,3), c("a", "b", "c"))
set_list_names <- function(l, n) {
    names(l) <- n
    return(l)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' custimized driopdown button
#'
#' @param label caption of the dropdown
#' @param status one of "default", "primary", "success", "info", "warning", "danger"
#' @param ... other paramenters
#' @param width width value
#'
#' @return HTML text
#' @export
#'
#' @examples dropdown_button("test", "default")
dropdown_button <- function(label = "", status = c("default", "primary",
                                                   "success", "info",
                                                   "warning", "danger"), ..., width = NULL) {

    status <- match.arg(status)
    # dropdown button content
    html_ul <- list(
        class = "dropdown-menu",
        style = if (!is.null(width))
            paste0("width: ", shiny::validateCssUnit(width), ";"),
        lapply(X = list(...),
               FUN = shiny::tags$li,
               style = "margin-left: 10px; margin-right: 10px;")
    )
    # dropdown button apparence
    html_button <- list(
        class = paste0("btn btn-", status, " dropdown-toggle"),
        type = "button",
        `data-toggle` = "dropdown"
    )
    html_button <- c(html_button, list(label))
    html_button <- c(html_button, list(shiny::tags$span(class = "caret")))
    # final result
    shiny::tags$div(
        class = "dropdown",
        do.call(shiny::tags$button, html_button),
        do.call(shiny::tags$ul, html_ul),
        shiny::tags$script(
            "$('.dropdown-menu').click(function(e) {
      e.stopPropagation();
});")
    )
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' cretes a list of lists from unique values of two columns in a data frame
#'
#' @param df dataframe
#' @param dim1 higher level dimension (column name)
#' @param dim2 lower level dimension (column name)
#' @param dim1_postfix if the highr level needs to have postfix value
#'
#' @return a named list of lists
#' @export
#'
#' @examples make_choice_list(iris, "Species", "Petal.Width")
make_choice_list <- function(df, dim1, dim2, dim1_postfix = "") {
    df_clean <- df %>% dplyr::select(!!dim1, !!dim2) %>% dplyr::distinct()
    names(df_clean) <- c("dim1", "dim2")
    val_dim1 <- unique(df_clean$dim1)
    t_choices <- lapply(sort(val_dim1), function(i) {
        items <- sort(unique((dplyr::filter(df_clean, dim1 == i))$dim2))
        res <- lapply(items, function(i) {
            i
        })
        return(res)
    }) %>% set_list_names(paste(sort(val_dim1), dim1_postfix))

    return(t_choices)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' provides leaflet map object
#'
#' @param dt dataframe that contains countries with metircs
#' @param df_map_data world map data
#' @param metric_name representative of value in df
#' @param for_shiny if true, then we need to have zoom control and dragable
#' @param lng1 east
#' @param lat1 north
#' @param lng2 west
#' @param lat2 south west
#' @param lng_center lng_center
#' @param lat_center lat_center
#' @param map_zoom map zoom
#' @param pal_domain range of values
#'
#' @return leaflet object
#' @export
#'
get_worldplot_leaflet <- function(dt, df_map_data, metric_name, for_shiny = TRUE,
                                  lng1 = -170, lat1 = 85,
                                  lng2 = 180, lat2 = -60,
                                  lng_center = 5.097656, lat_center = 42.81152,
                                  map_zoom = 2, pal_domain = NULL) {
    Indication <- unique(dt$Indication)
    legend_text <- "</br>(per 100,000)"
    if (Indication %in% c("Obesity", "Atopic dermatitis")) {
        legend_text <- "</br>(%)"
    }
    regions <- countries <- dt %>%
        dplyr::select("Country", "continent", "AmgenTiers") %>%
        dplyr::distinct()
    countries <- dt %>%
        dplyr::filter(!is.na(ISO.code)) %>%
        dplyr::group_by(Country, ISO.code) %>%
        dplyr::summarise(avgRating = mean(Value), .groups = "drop")
    # Add spatial data to countries dataframe
    countries <- countries %>% dplyr::left_join(df_map_data, c("ISO.code"))
    # Create color palette for map
    if (is.null(pal_domain)) {
        pal <- leaflet::colorNumeric(palette = "Greens", domain = countries$avgRating)
        pal_domain <- countries$avgRating
    }else{
        pal <- leaflet::colorNumeric(palette = "Greens", domain = pal_domain)
    }
    # Create label text for map
    map_labels <- paste(countries$Country,
                        " \n ", metric_name, " : ",
                        round(countries$avgRating, 1))
    map_labels <- lapply(seq(nrow(countries)), function(i) {
        regions_t <- regions %>% dplyr::filter(Country == countries$Country[i])
        paste0("<p><b>", countries$Country[i], "</b><p></p>",
               metric_name, ": ", round(countries$avgRating[i], 3), "<br>",
               "Region : ", regions_t$continent, "<br>",
               "Amgen tier : ", regions_t$AmgenTiers, "</p>")
    })


    # Generate basemap
    print("map render_mapviewer_data")

    map <- leaflet::leaflet(options = leaflet::leafletOptions(zoomControl = for_shiny,
                                                              dragging = for_shiny,
                                                              minZoom = 2, maxZoom = 5)) %>%
        leaflet::addTiles() %>%
        leaflet::setView(lng = lng_center,
                         lat = lat_center,
                         zoom = map_zoom)


    # Add polygons to map
    map <- map %>%
        leaflet::addPolygons(data = tibble::as_tibble(df_map_data)$geom,
                             fillOpacity = .7,
                             color = "grey",
                             weight = 1,
                             labelOptions = leaflet::labelOptions(textsize = "12px")) %>%
        leaflet::addPolygons(data = countries$geom,
                             fillColor = pal(countries$avgRating),
                             fillOpacity = .7,
                             color = "grey",
                             weight = 1,
                             label = lapply(map_labels, htmltools::HTML),
                             labelOptions = leaflet::labelOptions(textsize = "12px")) %>%
        leaflet::addLegend(pal = pal, title = paste0(metric_name, legend_text),
                           values = pal_domain,
                           position = "bottomleft") %>%
        leaflet::setMaxBounds(lng1 = lng1,
                              lat1 = lat1,
                              lng2 = lng2,
                              lat2 = lat2)
    return(map)
}


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' theme selector code generator
#'
#' @return java script and HTML code
#' @export
#'
theme_selector <- function() {
    shiny::div(
        shiny::div(
            shiny::selectInput("shinytheme-selector", "Choose a theme",
                               c("default", c("cerulean",  "cosmo",
                                              "cyborg", "darkly",
                                              "flatly", "journal",
                                              "lumen", "paper",
                                              "readable", "sandstone",
                                              "simplex", "slate",
                                              "spacelab", "superhero",
                                              "united", "yeti")),
                               selectize = FALSE
            )
        ),
        shiny::tags$script(
            "$('#shinytheme-selector')
        .on('change', function(el) {
        var allThemes = $(this).find('option').map(function() {
        if ($(this).val() === 'default')
        return 'bootstrap';
        else
        return $(this).val();
        });
        // Find the current theme
        var curTheme = el.target.value;
        if (curTheme === 'default') {
        curTheme = 'bootstrap';
        curThemePath = 'shared/bootstrap/css/bootstrap.min.css';
        } else {
        curThemePath = 'shinythemes/css/' + curTheme + '.min.css';
        }
        // Find the <link> element with that has the bootstrap.css
        var $link = $('link').filter(function() {
        var theme = $(this).attr('href');
        theme = theme.replace(/^.*\\//, '').replace(/(\\.min)?\\.css$/, '');
        return $.inArray(theme, allThemes) !== -1;
        });
        // Set it to the correct path
        $link.attr('href', curThemePath);
        });"
        )
    )
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' generate data table for map click views
#'
#' @param dt input data frame
#' @param country_name candidate country name
#'
#' @return DT object
#' @export
#'
country_dt_generator <- function(dt, country_name) {
    DT::renderDT({
        # Filter data based on selected Category , Region
        js <- c(
            "table.on('column-reorder', function(e, settings, details) {",
            "  Shiny.setInputValue('colOrder', details.mapping);",
            "});"
        )
        header_size <- DT::JS(
            "function(settings, json) {",
            "$(this.api().table().header()).css({'font-size': '70%'});",
            "}")
        dt_temp <- dt %>%
            dplyr::filter(Country == country_name) %>%
            dplyr::mutate(original_country_name = ifelse(is.na(original_country_name),
                                                         Country,
                                                         original_country_name)) %>%
            dplyr::select("original_country_name", "Measure", "Value") %>%
            dplyr::rename(Country = original_country_name)
        if (length(unique(dt_temp$Country)) == 1) {
            dt_temp <- dt_temp %>% dplyr::select("Measure", "Value")
        }

        DT::datatable(dt_temp, rownames = FALSE, style = "bootstrap",
                      selection = list(mode = "none"),
                      options = list(pageLength = 10,
                                     dom = "",
                                     initComplete = header_size,
                                     ordering = F
                      )
        ) %>%
            DT::formatStyle(columns = seq_len(ncol(dt_temp)), fontSize = "90%")
    })
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' resets map information
#' @param df_map_data all countries
#'
#' @return nothing
#' @export
#'
get_blank_map <- function(df_map_data) {

    map <- leaflet::leaflet(options = leaflet::leafletOptions(zoomControl = FALSE,
                                                              dragging = FALSE,
                                                              minZoom = 2,
                                                              maxZoom = 2)) %>%
        leaflet::addTiles() %>%
        leaflet::setView(lng = 5.097656,
                         lat = 42.81152, zoom = 2) %>%
        leaflet::setMaxBounds(lng1 = -170,
                              lat1 = 85,
                              lng2 = 180,
                              lat2 = -60) %>%
        leaflet::addPolygons(data = tibble::as_tibble(df_map_data)$geom,
                             fillOpacity = .7,
                             color = "grey",
                             weight = 1,
                             labelOptions = leaflet::labelOptions(textsize = "12px"))
    return(map)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' hide or show existing elements in the app
#'
#' @param hide_items element id for items to hide
#' @param show_items element id for items to show
#'
#' @return nothing
#' @export
#'
hide_show_manager <- function(hide_items = NULL, show_items = NULL) {
    if (!is.null(hide_items))
        lapply(hide_items, function(i) {
            shinyjs::hide(i, asis = TRUE)
        })
    if (!is.null(show_items))
        lapply(show_items, function(i) {
            shinyjs::show(i, asis = TRUE)
        })
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' creates an expanded bar plot
#'
#' @param dt input data table
#' @param population_measure name for polulation measure
#' @param min_val minimum value for x axes limit
#' @param max_val max value for x axes limit
#' @param y_title title for y axes (plot is flipped!)
#'
#' @return nothing
#' @export
#'
downloadable_get_barplot <- function(dt, population_measure, min_val, max_val, y_title = "") {
    df <- dt %>%
        dplyr::mutate(Country = ifelse(is.na(original_country_name), Country, original_country_name)) %>%
        dplyr::select("Country", "Value") %>%
        dplyr::mutate(Value = as.numeric(Value)) %>%
        dplyr::arrange(Value)
    df <- df %>%
        dplyr::filter(!is.na(df$Country))
    p <- ggplot2::ggplot(data = df,
                         ggplot2::aes(x = stats::reorder(Country,
                                                         sort(as.numeric(Value))),
                                      y = Value)) +
        ggplot2::geom_bar(stat = "identity",
                          color = "steelblue",
                          fill = "steelblue",
                          width = 0.2) +
        ggplot2::coord_flip() +
        ggplot2::scale_x_discrete(name = y_title,
                                  labels = function(x) formatC(x, width = 10)) +
        ggplot2::scale_y_continuous(name = population_measure,
                                    limits = c(min_val, max_val)) +
        ggplot2::geom_text(ggplot2::aes(label = Value), position = ggplot2::position_dodge(width = 0.9), hjust = -0.05)

    return(p)
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
protect <- function(code, msg_context = "N/A", show_alert = FALSE ){
    lazycode <- lazyeval::lazy(expr = code, env = parent.frame())

    result <- NULL
    try_catch({
        # Use withCallingHandlers to capture warnings but not drop out of the call
        result <- withCallingHandlers(
            eval(lazycode$expr, envir = parent.frame()),
            warning = function(w){
                print_stack_trace(w, lines = 25)
                warning(w)
            }
        )
    }, error = function(e) {
        if (is(e, "shiny.silent.error")) {
            stop(e)
        }

        print_stack_trace(e)

        if ( show_alert ) {
            shiny_alert(title = msg_context, message = e$message, type = 'warning')
        } else {
            Logger$logWarn(sprintf("Message Context: %s",msg_context))
        }
    })

    return(invisible(result))
}

