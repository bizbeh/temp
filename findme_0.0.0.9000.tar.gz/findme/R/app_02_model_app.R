#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' creating a model app
#'
#' @return r6 class
#' @export
#'
#' @examples \dontrun{findme::create_model_app()}
create_model_app <- function() {
    app_model <- shinygen::create_model_instance(
        name = "app_model",
        submodels = list(
            fm = create_new_fm_model()
        )
    )

    return(app_model)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' create fm model
#'
#' @return r6 class
#' @export
#'
#' @examples \dontrun{create_new_fm_model();}
create_new_fm_model <- function() {

    fm <- shinygen::create_model_instance(

        name = "fm",

        submodels = NULL,

        properties = list(
            EMPTY_CHOICE                           = " ",
            user_ldap_info                         = list(),
            input_data                             = NULL,
            filtering                              = FALSE,
            all_metrics                            = NULL,
            available_metrics                      = NULL,
            disease_choices                        = NULL,
            country_list                           = NULL,
            countervalue                           = 0,
            url_set_vlaue                          = FALSE,
            sign_up_wizard_module                  = NULL
        ),

        functions = list(
            get_sign_up_wizard_module = function(){
                if (is.null(self$sign_up_wizard_module)) {
                    self$sign_up_wizard_module <- sign_up_wizard_module$new()
                }
                return( self$sign_up_wizard_module )
            },
            update_country_list = function(country_list) {
                self$country_list <- country_list
            },
            initial_setup = function() {
                shinyjs::hide(id = "disease_population", asis = TRUE)
                shinyjs::hide(id = "population_measure", asis = TRUE)
                shinyjs::hide(id = "metric_range", asis = TRUE)
                shinyjs::hide(id = "global_dropdown", asis = TRUE)
                shinyjs::hide(id = "globalselection", asis = TRUE)
                shinyjs::hide(id = "data_source", asis = TRUE)
                shinyjs::hide(id = "year", asis = TRUE)
                shinyjs::hide(id = "sex", asis = TRUE)
                shinyjs::hide(id = "age", asis = TRUE)
                shinyjs::hide(id = "download_type", asis = TRUE)
                shinyjs::hide(id = "csv_save", asis = TRUE)
            },
            #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            #. ----
            # Load data fetch Functions ----
            #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            get_filtered_data = function(context, all_metrics = FALSE) {

                self$load_required_data()
                dt_temp <- self$input_data$dt_raw
                # # Filter dt_temp based on selected Country
                i_global_r <- context$input$globalR
                i_global_t <- context$input$globalT
                i_country <- context$input$Country
                shiny::isolate(i_disease <- context$input$disease)
                i_sex <- context$input$sex
                i_source <- context$input$data_source
                i_metric_range <- context$input$metric_range
                shiny::isolate(i_disease_population <- context$input$disease_population)
                shiny::isolate(i_population_measure <- context$input$population_measure)
                i_year <- context$input$year
                i_age <- context$input$age

                if (is.null(i_global_r) & is.null(i_global_t) & is.null(i_country)) {
                    i_country <- unique(dt_temp$Country)
                    i_global_t <- unique(dt_temp$AmgenTiers)
                    i_global_r <- unique(dt_temp$continent)
                }else{
                    if (is.null(i_country))
                        i_country <- ""
                    if (is.null(i_global_t))
                        i_global_t <- ""
                    if (is.null(i_global_r))
                        i_global_r <- ""
                }

                i_disease <- ifelse(is.null(i_disease), "", i_disease)
                i_sex <- ifelse(is.null(i_sex), "", i_sex)
                i_source <- ifelse(is.null(i_source), "", i_source)
                i_age <- ifelse(is.null(i_age), "", i_age)
                i_year <- ifelse(is.null(i_year), "", i_year)
                i_population_measure <- ifelse(is.null(i_population_measure), "", i_population_measure)
                i_disease_population <- ifelse(is.null(i_disease_population), "", i_disease_population)

                dt_temp <- dt_temp %>%
                    dplyr::filter((continent %in% i_global_r | AmgenTiers %in% i_global_t | Country %in% i_country) &
                                      Indication == i_disease & gender == i_sex & source == i_source &
                                      Population == i_disease_population & year == i_year & Age == i_age)

                if (!is.null(i_metric_range)) {
                    dt_selective <- dt_temp %>% dplyr::filter(round(Value, 1) >= i_metric_range[1] & round(Value, 1) <= i_metric_range[2])
                }

                dt_selective <- dt_temp %>% dplyr::filter(MetricName == i_population_measure)

                if (!all_metrics) {
                    dt_temp <- dt_selective
                }else{
                    if (nrow(dt_selective) > 0) {
                        dt_temp <- dt_temp %>% dplyr::filter(Country %in% dt_selective$Country)
                    }else{
                        dt_temp <- dt_selective
                    }
                }


                return(dt_temp)
            },
            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            load_required_data = function() {
                if (is.null(self$input_data)) {

                    dt_raw <- get_input_data()


                    dt_raw <- dplyr::as_tibble(dt_raw) %>%
                        dplyr::mutate(disease_category = dplyr::if_else(disease_category == "General medicine",
                                                                        "Non-Oncology",
                                                                        disease_category))
                    library(sf)
                    df_map_data <- spData::world[c(2, 11)]
                    df_map_data <- df_map_data %>%
                        dplyr::mutate(ISO.code = countrycode::countrycode(df_map_data$name_long,
                                                                          "country.name",
                                                                          c("iso3c"),
                                                                          custom_match = c("Kosovo" = "XKX",
                                                                                           "Somaliland" = "SOM"))) %>%
                        dplyr::mutate(continent = countrycode::countrycode(df_map_data$name_long,
                                                                           "country.name",
                                                                           c("continent"),
                                                                           custom_match = c("Antarctica" = "Antarctica",
                                                                                            "French Southern" = "Antarctica",
                                                                                            "Antarctic" = "Antarctica",
                                                                                            "Antarctic Lands" = "Antarctica",
                                                                                            "Kosovo" = "Europe")))



                    df_map_data[is.na(df_map_data$continent), ] <-  df_map_data[is.na(df_map_data$continent), ] %>% dplyr::mutate(continent = "Antarctica")
                    self$input_data <- list(dt_raw = dt_raw, df_map_data = df_map_data)
                    self$all_metrics <- unique(dt_raw$MetricName)
                    return(invisible(list(dt_raw = dt_raw, df_map_data = df_map_data)))
                }else{
                    return(NULL)
                }
            }

            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        )
    )
}
