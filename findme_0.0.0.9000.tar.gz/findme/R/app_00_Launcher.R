###++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
###
###           8888888b.  8888888888        d8888 8888888b.       888b     d888 8888888888
###           888   Y88b 888              d88888 888  "Y88b      8888b   d8888 888
###           888    888 888             d88P888 888    888      88888b.d88888 888
###           888   d88P 8888888        d88P 888 888    888      888Y88888P888 8888888
###           8888888P"  888           d88P  888 888    888      888 Y888P 888 888
###           888 T88b   888          d88P   888 888    888      888  Y8P  888 888
###           888  T88b  888         d8888888888 888  .d88P      888   "   888 888
###           888   T88b 8888888888 d88P     888 8888888P"       888       888 8888888888
###
###++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
###
###   This file creates the traditional ui and server objects, but only for consumption within the shiny app.R
###   that lives in findme/inst/application/*
###
###   You will see that findme/inst/application/app.R calls the 'create_shiny_app' function below.
###
###++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
###                                         [ LAUNCHER ]  ####
###
###   For DEVELOPMENT purposes within RStudio, it is easiest to launch findme via highlighting and running the following:
###
###
###                     devtools::load_all(".");    runShinyApp("findme", version = "master")
###
###comment here
###++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' create shiny app elements
#'
#' @return shiny app elements
#' @export
#'
#' @examples \dontrun{create_shiny_app()}
create_shiny_app <- function() {
    modules <- list(
    )

    app_title <- "Find Me"
    logopath <- system.file("application/master/www/findme_logo.png", package = "findme")
    if (!fs::file_exists(logopath)) {
        logopath <- system.file("inst/application/master/www/findme_logo.png", package = "findme")
    }

    # Main Entry Point UI
    #  Define the User Interface
    ui  <- shiny::fluidPage(title = app_title,
                            theme = shinythemes::shinytheme("cerulean"),

                            shinyjs::useShinyjs(),
                            shinyalert::useShinyalert(),
                            bsplus::use_bs_tooltip(),
                            bsplus::use_bs_popover(),

                            shiny::tagList(
                                shiny::tags$style("
                                             .findme-logo {
                                             height:30px;
                                             line-height: 30px;
                                            }
                              "),
                                shiny::tags$style("#signin_signup{
                                position: fixed;
                                right: 20px;
                                top: 5px;"),
                                MaxFitNavbarPage(id = "main_navbar",
                                                           #header =  shiny::tags$style(htmltools::HTML(".navbar-nav > li > a, .navbar-brand {height: 40%;}")),
                                                           title = htmltools::div(shiny::img(src = paste0("data:image/png;base64,",
                                                                                                          base64enc::base64encode(what = logopath,
                                                                                                                                  linewidth = "200")),
                                                                                             class = "findme-logo"),
                                                                                  htmltools::span(id = "app_title",
                                                                                                  style = "vertical-align: top; height: 100%; line-height: 10px; display: inline-block; padding-top:-0px;",
                                                                                                  shiny::tagList(
                                                                                                      shiny::tags$span(style = "font-size:8px;",
                                                                                                                       htmltools::HTML("<b>F</b>ind <br><b>M</b>e"))
                                                                                                  )),
                                                                                  htmltools::div(
                                                                                      id = "signin_signup",
                                                                                      shiny::actionButton("signin", "login"),
                                                                                      shiny::actionButton("signup", "create"),

                                                                                  )),
                                                           MaxFitTabPanel(title = "Home",
                                                                                    shiny::sidebarLayout(
                                                                                        shiny::sidebarPanel(width = 3,
                                                                                                            shinyjs::useShinyjs(),
                                                                                                            # Sidebar with a slider input
                                                                                                            shinyBS::bsCollapse(id = "sidepanelcollapse",
                                                                                                                                shinyBS::bsCollapsePanel(title = "Selection filters", style = "info",
                                                                                                                                                         shiny::actionButton("test", "search")),
                                                                                                                                shinyBS::bsCollapsePanel(title = "Selection filters", style = "info",
                                                                                                                                                         shiny::textInput("test", "search"))
                                                                                                            )
                                                                                        ),
                                                                                        # Show a plot of the generated distribution
                                                                                        shiny::mainPanel(width = 9,

                                                                                                         shiny::h1("map and result area")
                                                                                        )
                                                                                    )),
                                                           MaxFitTabPanel(title = "About", shiny::h1("about the tool")),
                                                           MaxFitTabPanel(title = "Admin", shiny::h1("admin stuff")),
                                                           MaxFitTabPanel(title = "Help", shiny::h1("help and contacts"))
                                )
                            )

    )

    #  Process the server  side updates -
    server <- function(input, output, session, ...) {

        app_model   <- findme::create_model_app()
        app_model$fm$initial_setup()
        app_model$fm$load_required_data()

        modules <- scope_modules_to_session(modules, session)

        for (module in modules) {
            # Delegate to each module's server function,
            # Be sure to name the function parameters
            module$server(modules = modules, app_model = app_model)
        }
        shiny::observeEvent(shiny::getUrlHash(), {
            hash <- gsub("#", "", shiny::getUrlHash())
            hash <- gsub("%20", " ", hash)

            shiny::updateNavbarPage(session = session, inputId = "main_navbar", selected = hash)

        }, priority = -100)

        shiny::observeEvent(input[["signup"]], {
            fm <- app_model$fm
            fm$get_sign_up_wizard_module()$server(modules = modules, app_model = app_model)
            sign_up_wizard_module$static$open_dialog(
                list(input = input,
                     session = session,
                     app_model = app_model,
                     modules = modules),
                wiz_panel = fm$get_sign_up_wizard_module()$ui()
            )

            # # Trigger activity after UI has rendered
            # shinyjs::delay( ms = 20, expr = {
            #     GEO$WIZARD_SCENARIO$scenario_dialog_open_count <- GEO$WIZARD_SCENARIO$scenario_dialog_open_count + 1
            # })
        })

    }
    return(
        list(
            ui        = ui,
            server    = server,
            modules   = modules
        )
    )
}
