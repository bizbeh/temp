#-----------------------------------------------------------------------------------------------
#           To help with regenerating this file, use:  amdevtools::make_roxygen_imports()
#-----------------------------------------------------------------------------------------------
#                            P A C K A G E     I M P O R T S
#-----------------------------------------------------------------------------------------------
#  NOTE: Only special packages that have a %xxx% structure are specifically imported.
#        Other packages are commented out from roxygen documentation to enforce
#        fully qualified function calls in this package.
#-----------------------------------------------------------------------------------------------
#' @importFrom magrittr "%>%"
#-----------------------------------------------------------------------------------------------
#### @importFrom bsplus use_bs_popover use_bs_tooltip
#### @importFrom countrycode countrycode
#### @importFrom datasets faithful iris mtcars USJudgeRatings
#### @importFrom dplyr arrange distinct filter group_by inner_join left_join mutate select summarise
#### @importFrom DT datatable dataTableOutput DTOutput JS renderDataTable renderDT
#### @importFrom ggplot2 aes coord_fixed coord_flip element_blank element_rect element_text geom_bar geom_polygon geom_text ggplot ggtitle map_data position_dodge scale_fill_distiller scale_x_discrete theme
#### @importFrom htmltools a attachDependencies br h3 hr HTML tagList validateCssUnit
#### @importFrom lazyeval lazy
#### @importFrom leaflet addLegend addPolygons addTiles colorNumeric labelOptions leaflet leafletOptions leafletOutput renderLeaflet setView
#### @importFrom methods is
#### @importFrom openxlsx addWorksheet insertPlot saveWorkbook writeDataTable
#### @importFrom plotly plotlyOutput
#### @importFrom rworldmap getMap
#### @importFrom shiny actionButton checkboxGroupInput checkboxInput dateInput dateRangeInput downloadButton downloadHandler fileInput fluidPage helpText HTML htmlOutput icon isolate mainPanel modalDialog navbarPage need numericInput observe observeEvent plotOutput radioButtons reactive renderPlot renderText renderUI req selectInput showModal sidebarLayout sidebarPanel sliderInput stopApp tabPanel tabsetPanel tags textAreaInput textInput updateCheckboxGroupInput updateSliderInput validate verticalLayout wellPanel
#### @importFrom shinyalert shinyalert useShinyalert
#### @importFrom shinyBS bsButton bsCollapse bsCollapsePanel bsPopover
#### @importFrom shinygen assert_is_valid_context create_model_instance create_module_definition FormCell FormLayout FormRow leftRightLayout scope_modules_to_session ScrollFitDiv ScrollFitNavbarPage ScrollFitTabPanel ScrollFitTabsetPanel ScrollFitVerticalLayout
#### @importFrom shinyjs hide show useShinyjs
#### @importFrom shinythemes shinytheme
#### @importFrom shinyWidgets pickerInput prettyCheckboxGroup updatePickerInput updatePrettyCheckboxGroup
#### @importFrom sp CRS over proj4string SpatialPoints
#### @importFrom spData world
#### @importFrom stats kmeans reorder
#### @importFrom tibble as_tibble
#### @importFrom utils data read.csv
#### @importFrom xlsx createWorkbook
#-----------------------------------------------------------------------------------------------
NULL

