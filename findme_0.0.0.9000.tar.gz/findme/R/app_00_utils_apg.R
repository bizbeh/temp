#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname is_set
#' @name   is_set
#' @title  is_set
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description Check if value is set.  Mainly checks to see if the value is not NA and is not NULL
#'    if the value is a list or vector, will check all values to be non NA/NULL
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @param the_value
#' * The value to check it exists
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **TRUE/FALSE**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'  assertthat::assert_that(FALSE == is_set(NA))
#'  assertthat::assert_that(FALSE == is_set(NULL))
#'  assertthat::assert_that(FALSE == is_set(c()))
#'  assertthat::assert_that(FALSE == is_set(c(NA)))
#'  assertthat::assert_that(FALSE == is_set(c(NULL)))
#'  assertthat::assert_that(TRUE  == is_set(c("something")))
#'  assertthat::assert_that(TRUE  == is_set("something"))
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
is_set <- function(the_value) {
  if (is.environment(the_value)) {
    return(TRUE)
  }
  if (is.null(the_value)) {
    return(FALSE)
  }
  if (is.list(the_value) || is.vector(the_value)) {
    is_set <- TRUE
    try_catch({
      is_set <- !all(is.na(the_value))
    }, error = function(e) {
      print_stack_trace(e)
      is_set <<- FALSE
    })
    return(is_set)
  }
  return(TRUE)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname is_blank
#' @name   is_blank
#' @title  is_blank
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description Check if value is blank.  only applies to values where is.character() == TRUE
#'    returns TRUE if the values is NULL, NA, or all whitespace, FALSE otherwise
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param the_value
#' * The value to check if is blank
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **TRUE/FALSE**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'   assertthat::assert_that(TRUE   == is_blank(NA))
#'   assertthat::assert_that(TRUE   == is_blank(NULL))
#'   assertthat::assert_that(TRUE   == is_blank(c()))
#'   assertthat::assert_that(TRUE   == is_blank(c(NA)))
#'   assertthat::assert_that(TRUE   == is_blank(c(NULL)))
#'   assertthat::assert_that(TRUE   == is_blank(""))
#'   assertthat::assert_that(TRUE   == is_blank(" "))
#'   assertthat::assert_that(TRUE   == is_blank(" \t "))
#'   assertthat::assert_that(TRUE   == is_blank(" \n "))
#'   assertthat::assert_that(FALSE  == is_blank(c("something")))
#'   assertthat::assert_that(FALSE  == is_blank("something"))
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
is_blank <- function(the_value) {
  if (is.character(the_value)) {
    if (length(the_value) > 0 && is.na(the_value)) {
      return(TRUE)
    }
    return(length(the_value) == 0 || nchar(trimws(the_value, "both")) == 0)
  } else if (!is_set(the_value)) {
    return(TRUE)
  } else {
    return(FALSE)
  }
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname is_not_blank
#' @name   is_not_blank
#' @title  is_not_blank
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description Check if value is NOT blank.  only applies to values where is.character() == TRUE
#'    returns FALSE if the values is NULL, NA, or all whitespace, TRUE otherwise
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param the_value
#' * The value to check if is not blank
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **TRUE/FALSE**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'   assertthat::assert_that(FALSE   == is_not_blank(NA))
#'   assertthat::assert_that(FALSE   == is_not_blank(NULL))
#'   assertthat::assert_that(FALSE   == is_not_blank(c()))
#'   assertthat::assert_that(FALSE   == is_not_blank(c(NA)))
#'   assertthat::assert_that(FALSE   == is_not_blank(c(NULL)))
#'   assertthat::assert_that(FALSE   == is_not_blank(""))
#'   assertthat::assert_that(FALSE   == is_not_blank(" "))
#'   assertthat::assert_that(FALSE   == is_not_blank(" \t "))
#'   assertthat::assert_that(FALSE   == is_not_blank(" \n "))
#'   assertthat::assert_that(TRUE    == is_not_blank(c("something")))
#'   assertthat::assert_that(TRUE    == is_not_blank("something"))
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
is_not_blank <- function(the_value) {
  return(!is_blank(the_value))
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname is_not_null
#' @name   is_not_null
#' @title  is_not_null
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description Check if value is NOT NULL.
#'    returns FALSE if the values is NULL, , TRUE otherwise
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param the_value
#' * The value to check if is not NULL
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **TRUE/FALSE**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'  assertthat::assert_that(TRUE    == is_not_null(NA))
#'  assertthat::assert_that(FALSE   == is_not_null(NULL))
#'  assertthat::assert_that(FALSE   == is_not_null(c()))
#'  assertthat::assert_that(TRUE    == is_not_null(c(NA)))
#'  assertthat::assert_that(FALSE   == is_not_null(c(NULL)))
#'  assertthat::assert_that(TRUE    == is_not_null(""))
#'  assertthat::assert_that(TRUE    == is_not_null(" "))
#'  assertthat::assert_that(TRUE    == is_not_null(c("something")))
#'  assertthat::assert_that(TRUE    == is_not_null("something"))
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
is_not_null <- function(the_value) {
  return(!is.null(the_value))
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname is_not_na
#' @name   is_not_na
#' @title  is_not_na
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description Check if value is NOT NA
#'    returns FALSE if the values is NA, , TRUE otherwise
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param the_value
#' * The value to check if is not NA
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **TRUE/FALSE**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'   assertthat::assert_that(FALSE   == is_not_na(NA))
#'   assertthat::assert_that(TRUE    == is_not_na(NULL))
#'   assertthat::assert_that(TRUE    == is_not_na(c()))
#'   assertthat::assert_that(FALSE   == is_not_na(c(NA)))
#'   assertthat::assert_that(TRUE    == is_not_na(c(NULL)))
#'   assertthat::assert_that(TRUE    == is_not_na(""))
#'   assertthat::assert_that(TRUE    == is_not_na(" "))
#'   assertthat::assert_that(TRUE    == is_not_na(c("something")))
#'   assertthat::assert_that(TRUE    == is_not_na("something"))
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
is_not_na <- function(the_value) {
  if (is.null(the_value)) {
    return(TRUE)
  } else if (is_set(the_value)) {
    return(TRUE)
  } else {
    return(!is.na(the_value))
  }
}


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname trim_to_empty
#' @name   trim_to_empty
#' @title  trim_to_empty
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description Remove whitespace from the front and back of strings, leave NA and NULL alone.
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param the_value
#' * The value to trim
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **trimmed value**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'  assertthat::assert_that(is.na(trim_to_empty(NA)))
#'  assertthat::assert_that(identical(NULL, trim_to_empty(NULL)))
#'  assertthat::assert_that(identical(c(), trim_to_empty(c())))
#'  assertthat::assert_that(identical(c(NULL), trim_to_empty(c(NULL))))
#'  assertthat::assert_that(identical(c(NA), trim_to_empty(c(NA))))
#'  assertthat::assert_that(""    == trim_to_empty(""))
#'  assertthat::assert_that(""    == trim_to_empty(" "))
#'  assertthat::assert_that(""    == trim_to_empty(c(" \n ")) )
#'  assertthat::assert_that("something"    == trim_to_empty(" something "))
#'  assertthat::assert_that("something\nelse"    == trim_to_empty(" something \n else "))
#'  assertthat::assert_that(
#'            identical(
#'                c("one","two\nthree"),
#'                trim_to_empty(c(" one ", " two \n  three "))
#'            )
#'  )
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
trim_to_empty <- function(the_value, convert_null = FALSE) {
  if (convert_null && (is.null(the_value))) {
    the_value <- ""
  }

  len <- length(the_value)

  if (len > 0) {
    for (i in 1:len) {
      tv <- the_value[[i]]
      if (convert_null && (is.null(tv) || (length(tv) == 1 && is.na(tv)))) {
        tv <- ""
      }

      if (is.character(tv)) {
        tmp <- unlist(strsplit(tv, "\n"))
        if (length(tmp) == 0) {
          tmp <- ""
        }
        tmp <- trimws(tmp, "both")
        if (!all(is.na(tmp))) {
          tv <- trimws(paste0(tmp, collapse = "\n"))
        } else {
          tv <- tmp
        }
      }
      the_value[[i]] <- tv
    }
  }

  return(the_value)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
trim_to_blank <- function(the_value) {
  return(trim_to_empty(the_value, convert_null = TRUE))
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname ENUM
#' @name   ENUM
#' @title  ENUM
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description A factory method for creating Java-like static enums
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param type
#' * The name of the ENUM to create
#'    * Default: NONE
#'
#' @param values
#' * A list of lists. The first level of named entries are the ENUM entries. The named entries for each ENUM value are the name/value pair properties for each enumerated value.
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **The ENUM**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'  #---------------------------------------------------
#'  # Define an enumeration
#'  #---------------------------------------------------
#'  CAR <- ENUM$create(
#'      "CAR",
#'      list(
#'          COLT = list(
#'              ordinal = 1,
#'              speed   = "slow"
#'          ),
#'          MUSTANG = list(
#'              ordinal = 2,
#'              speed   = "fast"
#'          ),
#'          FERRARI = list(
#'              ordinal = 3,
#'              speed   = "faster"
#'          )
#'      )
#'  )
#'
#'  #---------------------------------------------------
#'  # Ask enum for all of it's values
#'  #---------------------------------------------------
#'
#'  for( enum in CAR$values) {
#'      print( enum$name )
#'  }
#'
#'  #---------------------------------------------------
#'  # Ask enum for all of it's value names
#'  #---------------------------------------------------
#'
#'  for( n in CAR$names) {
#'      print( n )
#'  }
#'

#'
#'  #---------------------------------------------------
#'  # Ask individual enum value for their properties
#'  #---------------------------------------------------
#'
#'  assertthat::assert_that( "COLT"    == CAR$COLT$name )
#'  assertthat::assert_that( "1"       == CAR$COLT$ordinal )
#'  assertthat::assert_that( "slow"    == CAR$COLT$speed )
#'
#'  assertthat::assert_that( "MUSTANG" == CAR$MUSTANG$name )
#'  assertthat::assert_that( "2"       == CAR$MUSTANG$ordinal )
#'  assertthat::assert_that( "fast"    == CAR$MUSTANG$speed )
#'
#'  assertthat::assert_that( "FERRARI" == CAR$FERRARI$name )
#'  assertthat::assert_that( "3"       == CAR$FERRARI$ordinal )
#'  assertthat::assert_that( "faster"  == CAR$FERRARI$speed )
#'
#'  #---------------------------------------------------
#'  # Static function on ENUM to get all defined ENUM types
#'  #---------------------------------------------------
#'  for( type in ENUM$TYPES ){
#'      print( class(type)[1] )
#'  }
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ENUM        <- new.env()
ENUM$TYPES  <- list()
ENUM$create <- function(type = "COLOR", values = list(RED = list(value = 1), GREEN = list(value = 2), BLUE = list(value = 3))) {
  TheType <- R6::R6Class(
    classname = type,
    private   = list(
      my_values = list()
    ),
    public    = list(
      from_string = function(name) {
        return(private$my_values[[name]])
      }
    ),
    active    = list(
      values = function(aValue) {
        if (missing(aValue)) {
          return(private$my_values)
        } else {
          warning("The values of an enumeration are readonly", immediate. = TRUE)
          return(invisible(NULL))
        }
      },
      names  = function(aValue) {
        if (missing(aValue)) {
          return(names(private$my_values))
        } else {
          warning("The names of an enumeration are readonly", immediate. = TRUE)
          return(invisible(NULL))
        }
      }
    )
  )

  for (vName in names(values)) {
    TheType$set("active", vName, eval(parse(text = gfmt("function(aValue){{
            if( missing(aValue)){{
                return(private$my_values[['{vName}']])
            }}
            stop('This value is immutable')
        }}"))))
  }
  x <- TheType$new()
  for (vName in names(values)) {
    value                                        <- values[[vName]]
    value[["name"]]                              <- eval(parse(text = gfmt("'{vName}'")))
    value[["to_string"]]                         <- eval(parse(text = gfmt("function(){{
            return('{vName}')
        }}")))
    x$.__enclos_env__$private$my_values[[vName]] <- value
  }

  ENUM$TYPES[[type]] <- x

  return(x)
}



#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname first_not_blank
#' @name   first_not_blank
#' @title  first_not_blank
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description returns the first parameter that is not blank
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param ...
#' * character values
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **The first parameter value that is not blank**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'  assertthat::assert_that(is.null(first_not_blank(NULL)))
#'  assertthat::assert_that(is.null(first_not_blank(NA)))
#'  assertthat::assert_that(is.null(first_not_blank(NULL, NA)))
#'  assertthat::assert_that("1"    == first_not_blank("1", NULL))
#'  assertthat::assert_that("1"    == first_not_blank("1", "2", NA))
#'  assertthat::assert_that("1"    == first_not_blank(NULL, "1", "2", NULL))
#'  assertthat::assert_that("1"    == first_not_blank(NA, "1", "2", NULL))
#'  assertthat::assert_that("1"    == first_not_blank(NULL, NA, "1", "2", NULL))
#'  assertthat::assert_that("1"    == first_not_blank(NULL, NA, "", "1", "2", NULL))
#'  assertthat::assert_that("1"    == first_not_blank(NULL, NA, "\n", "1", "2", NULL))
#'  assertthat::assert_that("1"    == first_not_blank(NULL, NA, "\n \n", "1", "2", NULL))
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
first_not_blank <- function(...) {
  args <- list(...)
  for (arg in args) {
    if (is.null(arg) || isTRUE(is.na(arg))) {
      # continue
    } else if (is_not_blank(arg)) {
      return(arg)
    }
  }
  return(NULL)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname first_not_nullna
#' @name   first_not_nullna
#' @title  first_not_nullna
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description returns the first parameter that is not blank
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param ...
#' * character values
#'    * Default: NONE
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **The first parameter value that is not blank**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'  assertthat::assert_that(is.null(first_not_nullna(NULL)))
#'  assertthat::assert_that(is.null(first_not_nullna(NA)))
#'  assertthat::assert_that(is.null(first_not_nullna(NULL, NA)))
#'  assertthat::assert_that("1"     == first_not_nullna("1", NULL))
#'  assertthat::assert_that("1"     == first_not_nullna("1", "2", NA))
#'  assertthat::assert_that("1"     == first_not_nullna(NULL, "1", "2", NULL))
#'  assertthat::assert_that("1"     == first_not_nullna(NA, "1", "2", NULL))
#'  assertthat::assert_that("1"     == first_not_nullna(NULL, NA, "1", "2", NULL))
#'  assertthat::assert_that(""      == first_not_nullna(NULL, NA, "", "1", "2", NULL))
#'  assertthat::assert_that("\n"    == first_not_nullna(NULL, NA, "\n", "1", "2", NULL))
#'  assertthat::assert_that("\n \n" == first_not_nullna(NULL, NA, "\n \n", "1", "2", NULL))
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
first_not_nullna <- function(...) {
  args <- list(...)
  for (arg in args) {
    if (is_set(arg)) {
      return(arg)
    }
  }
  return(NULL)
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
view_df <- function(df, pageLength = 9999, colFilter = c("none", "bottom", "top")) {
  if (missing(colFilter)) {
    colFilter <- "bottom"
  }

  options(DT.options = list(pageLength = pageLength))
  DT::datatable(df, rownames = FALSE, filter = colFilter)
}


#' @export
rebind_symbol <- function(a_symbol, a_value, a_package = globalenv()) {
  if (exists(a_package, mode = "environment")) {
    env <- as.environment(sprintf("package:%s", a_package))
  } else {
    env <- asNamespace(a_package)
  }

  symbolExists <- !is.null(env) && exists(a_symbol, envir = env)

  if (symbolExists) {
    unlockBinding(a_symbol, env)
  }

  assign(a_symbol, value = a_value, envir = env)

  if (symbolExists) {
    lockBinding(a_symbol, env)
  }
}



# Essentially, catch and handle integer(0) objects
#' @export
to_valid_integer <- function(value, default_value = 0) {
  try_catch({
    val <- as.integer(value)
    if (is.null(val) || is.na(val) || length(val) == 0) {
      val <- default_value
    }
  }, error = function(e) {
    val <<- 0
  })
  return(val)
}

# Essentially, catch and handle integer(0) objects
#' @export
first_integer_gt_zero <- function(...) {
  vals <- list(...)
  for (val in vals) {
    val <- to_valid_integer(val)
    if (val > 0) {
      return(val)
    }
  }
  return(0)
}

#' @export
stop_if_not_true <- function(test, msg = "Failed Assertion") {
  OK     <- FALSE
  reason <- NULL
  try_catch({
    if (isTRUE(test)) {
      OK     <- TRUE
      reason <- NULL # No exception to get additional details.
    }
  }, error = function(e) {
    OK     <<- FALSE
    reason <<- e$message # We will add this to the stop reason
    # print_stack_trace(e)
  })

  if (!OK) {
    if (is.null(reason)) {
      stop(msg)
    } else {
      stop(sprintf("%s\n\tReason: %s", msg, reason))
    }
  }
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++
#  A concatenation operator that works like java's
#     x = "a"
#     x += "1"
#     x == "a1"
#+++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
"%+=%" <- function(lhs, rhs) {
  if (is.null(rhs) || length(rhs) == 0) {
    rhs <- ""
    warning("Operator `%+=%` right-hand-side was character(0)...converting to blank ''.", immediate. = TRUE)
  }
  parent   <- parent.frame()
  env      <- new.env(parent = parent)
  the_call <- match.call()

  # Parent environments variable name that was passed in
  lhs_var_name <- as.character(the_call$lhs)
  # Get value of lhs variable
  lhs_value <- get(x = lhs_var_name, envir = parent)

  # concatenate lhs + rhs
  value <- sprintf("%s%s", lhs_value, rhs)

  # update the lhs variable with new concatenated variable
  eval(call("<-", lhs_var_name, value), parent, parent)
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++
#  Long form concatenation
#     x = "a"
#     x <- concat(x,"1")
#     x == "a1"
#+++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
concat <- function(base, ...) {
  args <- list(...)
  out  <- base
  for (val in args) {
    out <- sprintf("%s%s", out, val)
  }
  return(out)
}



#+++++++++++++++++++++++++++++++++++++++++++++++++++
#  Safer rbind(df1, df2) that also adds missing
#    columns prior to binding
#+++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
row_bind_with_column_fix <- function(df1, df2, add_missing_columns = FALSE) {
  if (!is.null(df1) && !is.null(df2) && nrow(df2) > 0 && ncol(df2) > 0) {
    if (add_missing_columns && nrow(df1) > 0 && nrow(df2) > 0) {
      df2_missing <- setdiff(names(df1), names(df2))
      if (length(df2_missing) > 0) {
        df2[df2_missing] <- NA
      }

      df1_missing <- setdiff(names(df2), names(df1))
      if (length(df1_missing) > 0) {
        df1[df1_missing] <- NA
      }
    }

    df1 <- rbind(df1, df2, stringsAsFactors = FALSE)
  }

  return(df1)
}


#' @export
to_tribble <- function(indf, df_name = NULL, indents = 4, mdformat = TRUE, assign_symbol = "<-") {
  if (is.null(df_name)) {
    name <- as.character(substitute(indf))
    name <- trimws(name[length(name)], "both")
  } else {
    name <- df_name
  }

  meat <- capture.output(utils::write.csv(indf, quote = TRUE, row.names = FALSE))
  meat <- paste0(
    paste(rep(" ", indents), collapse = ""),
    c(
      paste(sprintf("~%s", names(indf)), collapse = ", "),
      meat[-1]
    )
  )

  if (mdformat) {
    meat <- paste0("    ", meat)
  }
  obj <- paste(paste(rep(" ", indents), collapse = ""), name, " ", assign_symbol, " tibble::tribble(\n", paste(meat, collapse = ",\n"), "\n", paste(rep(" ", indents), collapse = ""), ")", sep = "")

  return(obj)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
seconds_to_duration_str <- function(seconds) {
  res <- purrr::map_chr(seconds, function(seconds) {
    ss       <- seconds %% 60
    m        <- (seconds - ss) / 60
    mm       <- m %% 60
    hh       <- (m - mm) / 60
    duration <- sprintf("%02i H : %02i M : %02i S", as.integer(hh), as.integer(mm), as.integer(ss))
    return(duration)
  })
  return(res)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Internal helper for gfmt()
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
glue_sprintf_transformer <- function(text, envir) {
  m <- regexpr(":.+$", text)
  if (m != -1) {
    format              <- substring(regmatches(text, m), 2)
    regmatches(text, m) <- ""
    res                 <- eval(parse(text = text, keep.source = FALSE), envir)
    do.call(sprintf, list(glue::glue("%{format}"), res))
  } else {
    eval(parse(text = text, keep.source = FALSE), envir)
  }
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname gfmt
#' @name   gfmt
#' @title  gfmt
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description A simple wrapper around glue::glue() to support in-line formatting of variables like sprintf() supports with %xxx notations.
#'   see https://stat.ethz.ch/R-manual/R-devel/library/base/html/sprintf.html for formatting options
#'
#' To format a variable 'x', use a colon after the variable name, and then the sprintf format tag:
#'   ```
#'   x <- 1234.56789
#'   gfmt(" 0 decimal places: {x:.0f}")
#'   gfmt(" 1 decimal places: {x:.1f}")
#'   gfmt(" 2 decimal places: {x:.2f}")
#'   ```
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param ...
#' * Any string that is valid in glue::glue
#'    * Default: NONE
#'
#' @param .envir
#' * an optional environment reference
#'    * Default: parent.frame()
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **Formatted String**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'   dog <- "bertinousificous"
#'   cat <- "dilbert"
#'   gfmt("π = {pi:.6f} for '{dog:10.10s}' and '{cat:10s}'")
#'
#'   x <- 1234.56789
#'   gfmt(" 0 decimal places: {x:.0f}")
#'   gfmt(" 1 decimal places: {x:.1f}")
#'   gfmt(" 2 decimal places: {x:.2f}")
#'
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
gfmt <- function(..., .envir = parent.frame()) {
  as.character(glue::glue(..., .transformer = glue_sprintf_transformer, .envir = .envir))
}


options(appgen.try_catch.debug = FALSE)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname get_stack_trace
#' @name   get_stack_trace
#' @title  get_stack_trace
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description A helper function to fill in a stacktrace value for an error or warning
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @param e
#' * The error or warning to trace
#'    * Default: none
#' @param lines
#' * The number of error lines to return
#'    * Default: 50
#' @param print_tree
#' * Whether or not to print a tree at end of trace
#'    * Default: TRUE
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **the stack trace**
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#' \dontrun{
#'  get_stack_trace(simpleWarning("foo happened"))
#' }
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
get_stack_trace <- function(e, lines = 50, print_tree = FALSE) {
  tmp    <- sys.calls()
  tmpEnd <- length(tmp)
  cnt    <- 0
  # Try to remove some junk off the top of the stacktrace and get to the root of the cause
  for (i in length(tmp):1) {
    cnt  <- cnt + 1
    if (cnt > 25) {
      # if we have gone down 25 stack levels, we probably aren't going to find what we think we are looking for, so bail
      break
    }
    line <- tmp[i]
    if (grepl("^withRestarts", line) || grepl("^\\.handleSimpleError", line)) {
      tmpEnd <- i - 1
    }
  }

  tmp <- tmp[1:tmpEnd]

  #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  # Remove some boilerplate error stuff
  #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  # First, look for function names on the calls (element[[1]])
  tmp_calls <- lapply(tmp, function(x) {
    x[[1]]
  })
  tmp       <- tmp[!grepl(
    paste0(
      "(",
      "get_stack_trace",
      "|print_stack_trace",
      "|withVisible",
      "|evalVis",
      "|doTryCatch",
      "|tryCatchOne",
      "|tryCatchList",
      "|withCallingHandlers",
      ")"
    ),
    tmp_calls
  )]

  # Next look for string patterns in the full function text
  tmp <- tmp[!grepl("eval\\(expr, pf\\)", tmp)]
  tmp <- tmp[!grepl("paste0\\(get_stack_trace", tmp)]
  tmp <- tmp[!grepl("tryCatch\\(.*withCallingHandlers", tmp)]

  stacktrace <- ""
  if (is(e, "simpleError") || is(e, "simpleWarning")) {
    if (is(e, "simpleError")) {
      stacktrace <- c(stacktrace, sprintf("Error: %s\n", e$message))
    } else {
      stacktrace <- c(stacktrace, sprintf("Warning: %s\n", e$message))
    }
    stacktrace <- c(stacktrace, sprintf(" Call: %s\n", capture.output(print(e$call))))
  }

  if (length(tmp) > 0) {
    for (i in length(tmp):1) {
      srcLine    <- trim_to_empty(extract_srcLocation(tmp[[i]])[[2]])
      if (!is_blank(srcLine)) {
        srcLine <- sprintf(" [%s]", srcLine)
      }
      stacktrace <- c(stacktrace, sprintf(" %3i: at %s%s\n", i, gsub("\n", "\n\t ", tmp[i]), srcLine))
    }
  }

  if (length(stacktrace) == 0) {
    stacktrace <- capture.output(print(e))
  }
  stacktrace <- c(stacktrace, "\n")

  tryCatch({
    if (min(length(stacktrace), lines) > 0) {
      stacktrace <- stacktrace[1:min(length(stacktrace), lines)]
      if (print_tree) {
        last_trace <- rlang::last_trace()
        stacktrace <- c(stacktrace, "\n------------------------------------------------------------")
        stacktrace <- c(stacktrace, sprintf("\nError: %s", e$message))
        stacktrace <- c(stacktrace, sprintf("\n Call: %s\n", capture.output(print(e$call))))
        stacktrace <- c(stacktrace, paste0(capture.output(print(last_trace)), collapse = "\n"))
      }
    }
  }, error = function(e) {
    # Ignore, just return the normal trace
  })


  return(stacktrace)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname try_catch
#' @name   try_catch
#' @title  try_catch
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description An enhanced version of tryCatch() that populates error and warning objects with a e$stacktrace to help debug source of error.
#'   see https://stat.ethz.ch/R-manual/R-devel/library/base/html/conditions.html
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param expr
#' * The expression to watch for errors and warnings
#'    * Default: none
#'
#' @param ...
#' * The same values as tryCatch...see https://stat.ethz.ch/R-manual/R-devel/library/base/html/conditions.html
#'    * Default: none
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **result of `expr`**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#' \dontrun{
#'  try_catch({
#'     message("Before Error")
#'     stop("foo happened")
#'     message("After error...should not get called.")
#'
#'  }, error = function(e){
#'      message(sprintf("An error occurred: '%s'", e$message))
#'      print_stack_trace(e)
#'
#'  }, finally = {
#'    message("Cleanup from finally block")
#'  })
#'
#' }
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
try_catch <- function(expr, ...) {
  myErrorHandler <- function(e) {
    appgen.try_catch.debug <- getOption("appgen.try_catch.debug", FALSE)
    if (appgen.try_catch.debug) {
      message("In try_catch myErrorHandler: ", e$message)
    }
    if ("stacktrace" %in% names(e)) {
      # We have already caught this and rethrown it...just propagate it up
      # Propagate to outer try/catch
      stop(e)
    } else {
      if (is.null(e$trace)) {
        # Try to add an rlang error trace to this error
        tryCatch({
          e$trace <- rlang::last_trace()
        }, error = function(e) {
          # ignore, not R 3.5+
        })
      }

      tt           <- get_stack_trace(e)
      e$stacktrace <- paste0(tt, collapse = "")
      # Propagate to outer try/catch
      stop(e)
    }
  }

  myWarningHandler <- function(e) {
    appgen.try_catch.debug <- getOption("appgen.try_catch.debug", FALSE)
    if (appgen.try_catch.debug) {
      message("In try_catch myWarningHandler: ", e$message)
    }
    if ("stacktrace" %in% names(e)) {
      # We have already caught this and rethrown it...just propagate it up
      # Propagate to outer try/catch
      warning(e)
    } else {
      tt           <- get_stack_trace(e)
      e$stacktrace <- paste0(tt, collapse = "")
      # Propagate to outer try/catch
      warning(e)
    }
  }
  tryCatch({
    withCallingHandlers(expr, error = myErrorHandler, warning = myWarningHandler)
  }, ...)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname print_stack_trace
#' @name   print_stack_trace
#' @title  print_stack_trace
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description A helper function to print a stacktrace for an error or warning.
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param e
#' * The error or warning object to print a stacktrace for.
#'    * Default: {blank}
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **NOTHING**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#' \dontrun{
#'  print_stack_trace(simpleWarning("foo happened"))
#' }
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
print_stack_trace <- function(e, lines = 30, print_tree = FALSE) {
  tryCatch({
    stacktrace <- NULL
    if ("stacktrace" %in% names(e)) {
      stacktrace <- e[["stacktrace"]]
    } else {
      stacktrace <- paste0(get_stack_trace(e, lines = lines, print_tree = print_tree), collapse = "")
    }

    # Limit to requested number of lines
    stacktrace <- gsub("\\n", "", unlist(strsplit(stacktrace, "\n")))
    stacktrace <- stacktrace[1:min(lines, length(stacktrace))]

    if (methods::is(e, "error")) {
      Logger$logError(paste0("\n", stacktrace, collapse = ""))
    } else if (methods::is(e, "warning")) {
      Logger$logWarn(paste0("\n", stacktrace, collapse = ""))
    } else {
      Logger$logInfo(paste0("\n", stacktrace, collapse = ""))
    }
  }, error = function(e) {
    Logger$logInfo(paste0("\n", "try_catch.print_stack_trace - Error rendering stackrace: ", e$message, collapse = "\n"))
  })
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname convert_warning_to_error
#' @name   convert_warning_to_error
#' @title  convert_warning_to_error
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description A helper function to convert a warning into an error. Typically used in a try_catch{},warning) block
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param w
#' * The warning objec to convert to an error object
#'    * Default: {blank}
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **A SimpleError object**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#' \dontrun{
#'
#'  try_catch({
#'     warning("foo happened")
#'  }, warning = function(w){
#'     # upgrade to error and re-throw
#'     stop(convert_warning_to_error(w))
#'  })
#'
#' }
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
convert_warning_to_error <- function(w) {
  err <- simpleError(w$message, w$call)
  if ("stacktrace" %in% names(w)) {
    err$stacktrace <- w[["stacktrace"]]
  }
  return(err)
}


#' Return the first or last part of a list
#'
#' Returns the first or last part of a list. Instead of returning the first
#' n entries as the standard head() does, it attempts to call head()
#' recursively on the entries in the list. If it fails, it will return the
#' particular entry (standard behavior).
#' @param obj a list object
#' @param n a single integer. If positive, prints the first n items for the
#' list and all entries in the list. If negative, prints all but the last
#' n items in the list.
#' @return a list of length n, with items in the list of length n
head.list              <- function(obj, n = 6L, ...) {
  stopifnot(length(n) == 1L)
  origN <- n
  n     <- if (n < 0L) {
    max(length(obj) + n, 0L)
  } else {
    min(n, length(obj))
  }
  lapply(obj[1:length(n)], function(x) {
    tryCatch({
      head(x, origN, ...)
    }, error = function(e) {
      x
    })
  })
}
environment(head.list) <- asNamespace("utils")


dmsg <- function(..., debug = FALSE) {
  if (debug) {
    cat(paste0(..., "\n", collapse = "\n"))
  }
}

extract_srcLocation <- function(loc) {
  srcLocation      <- c("", "")
  srcLocation[[1]] <- deparse(loc[[1]])[[1]]

  locType <- typeof(loc)
  # if ( "language" == locType ){
  if (!is.null(srcinfo <- attr(loc, "srcref"))) {
    srcf        <- attr(srcinfo, "srcfile")
    srcl        <- srcinfo[1]
    srcFilename <- ""
    if (is_not_blank(srcf$filename)) {
      srcFilename <- basename(srcf$filename)
    }
    if (is.integer(srcl)) {
      srcLocation[[2]] <- sprintf("%s#%03i", srcFilename, as.integer(srcl))
    }
  }
  # }
  return(srcLocation)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Helper method to find the line number of the calling method
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
find_line_number_of_calling_method <- function(after) {
  DEBUG <- getOption("appgen.logline.debug", FALSE)

  tmp                 <- rev(sys.calls())
  foundStartingFrame  <- FALSE
  foundSourceLocation <- NULL

  if (DEBUG) {
    dmsg(debug = DEBUG, "\n========================================================================================")
    dmsg(debug = DEBUG, sprintf("|-----> at method ['%-40.40s']:  [%-30.30s]  [%-5.5s == GREP('%s')]", "Method", "File/Line", "Match", "RegEx"))
    for (i in 1:length(tmp)) {
      loc              <- tmp[[i]]
      srcLocation      <- extract_srcLocation(loc)
      locName          <- deparse(loc[[1]])
      is_matching_line <- grepl(after, locName, perl = TRUE, ignore.case = TRUE)
      dmsg(debug = DEBUG, sprintf("|-----> at method ['%-40.40s']:  [%-30.30s]  [%-5.5s == GREP('%s')]", srcLocation[[1]], srcLocation[[2]], is_matching_line, after))
    }
  }

  for (i in length(tmp):1) {
    loc <- NULL
    if (length(tmp) >= i) {
      loc <- tmp[[i]]
    }

    locType     <- typeof(loc)
    srcLocation <- extract_srcLocation(loc)

    locName          <- srcLocation[[1]]
    is_matching_line <- grepl(after, locName, perl = TRUE, ignore.case = TRUE)
    if (!foundStartingFrame && is_matching_line) {
      foundStartingFrame  <- TRUE
      foundSourceLocation <- srcLocation
      if ("withCallingHandlers" != srcLocation[[1]] && "tryCatchList" != srcLocation[[1]] && "tryCatch" != srcLocation[[1]]) {
        return(srcLocation[[2]])
      }
    } else if (foundStartingFrame) {
      if (is_not_blank(srcLocation[[2]]) && "withCallingHandlers" != srcLocation[[1]] && "tryCatchList" != srcLocation[[1]] && "tryCatch" != srcLocation[[1]]) {
        return(srcLocation[[2]])
      }
    }
  }
  return("")
}

remove_newlines_from_start_and_end <- function(msg) {
  # Trim all starting and trailing newlines so we start with a known state
  while (startsWith(msg, "\n")) {
    if (nchar(msg) == 1) {
      msg <- ""
    } else {
      msg <- substr(msg, 2, nchar(msg))
    }
  }
  while (endsWith(msg, "\n")) {
    if (nchar(msg) == 1) {
      msg <- ""
    } else {
      msg <- substr(msg, 1, nchar(msg) - 1)
    }
  }
  return(msg)
}

flatten <- function(msg) {
  msg <- paste0(msg, collapse = "\n")
  return(msg)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
as_not_loggable <- function(obj) {
  if (!is(obj, "NOT_LOGGABLE")) {
    class(obj) <- c("NOT_LOGGABLE", class(obj))
  }
  return(obj)
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
as_loggable <- function(obj) {
  if (is(obj, "NOT_LOGGABLE")) {
    class(obj) <- class(obj)[!(class(obj) %in% "NOT_LOGGABLE")]
  }
  return(obj)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
is_loggable <- function(obj) {
  return(!is(obj, "NOT_LOGGABLE"))
}


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
to_log_string <- function(object, max_print = 4999, max_print_data_rows = 999999) {
  if (!is_loggable(object)) {
    return("[Not logged since object is marked with class 'NOT_LOGGABLE']")
  }

  myPreviousMaxPrint <- getOption("max.print")
  tryCatch({
    options("max.print" = max_print)
    head_rows     <- NULL
    real_rows     <- NULL
    rows_verbiage <- NULL
    if (!is.null(object)) {
      if (tibble::is_tibble(object) || is.data.frame(object) || is.matrix(object)) {
        real_rows     <- nrow(object)
        head_rows     <- min(real_rows, max_print_data_rows)
        rows_verbiage <- "rows"
        if (!is.null(head_rows) && !is.null(real_rows) && head_rows < real_rows) {
          object <- head(object, head_rows)
        }
      } else if (is.list(object)) {
        real_rows     <- max(length(object), ifelse(length(object) == 0, 0, length(object[[1]])))
        head_rows     <- min(real_rows, max_print_data_rows)
        rows_verbiage <- "elements and/or element values"
        if (!is.null(head_rows) && !is.null(real_rows) && head_rows < real_rows) {
          object <- head(object, head_rows)
        }
      } else if (is.vector(object)) {
        real_rows     <- length(object)
        head_rows     <- min(real_rows, max_print_data_rows)
        rows_verbiage <- "elements"
        if (!is.null(head_rows) && !is.null(real_rows) && head_rows < real_rows) {
          object <- head(object, head_rows)
        }
      }

      if (!is.null(head_rows) && !is.null(real_rows) && head_rows >= real_rows) {
        # NO-OP
        real_rows <- NULL
        head_rows <- NULL
      }
    }

    if (tibble::is_tibble(object)) {
      msg <- flatten(capture.output(print(object, n = 4999)))
    } else {
      msg <- flatten(capture.output(print(object)))
    }

    if (!is.null(head_rows)) {
      msg <- flatten(sprintf("%s\n\n%s", msg, gfmt("\t [ Output truncated to {head_rows} of {real_rows} total {rows_verbiage}. ]")))
    }
  }, finally = {
    options("max.print" = myPreviousMaxPrint)
  })

  return(msg)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
print_long_output <- function(output, max_print = 4999, connections = NULL) {
  myMaxPrint <- getOption("max.print")
  tryCatch({
    options("max.print" = max_print)

    # Print to console
    cat(sprintf("%s\n", output))

    # If any extra connections, log to them
    if (!is.null(connections) && length(connections) > 0) {
      for (conn in connections) {
        cat(sprintf("%s\n", output), file = conn, append = TRUE)
      }
    }
  }, finally = {
    options("max.print" = myMaxPrint)
  })
}

indent_multiline_message <- function(msg) {
  msg <- flatten(msg)
  if (any(grepl("\n", msg))) {
    msg <- gsub("\n", "\n\t", msg, perl = TRUE)
  }
  return(msg)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname Logger
#' @name   Logger
#' @title  Logger
#' @description A helper class to log messages at various log levels of  TRACE, DEBUG, INFO, WARN, ERROR, ALERT.
#'
#' You can set the minimum log level to print with the Logger$setLogLevel( theLevel ) function where `theLevel` is one of:
#'
#' * Logger$setLogLevel('OFF')
#' * Logger$setLogLevel('ALERT')
#' * Logger$setLogLevel('ERROR')
#' * Logger$setLogLevel('WARN')
#' * Logger$setLogLevel('INFO')
#' * Logger$setLogLevel('DEBUG')
#' * Logger$setLogLevel('TRACE')
#'
#' You can log messages at differnt log levels by using one of the logXXXX methods. Only messages at or above the set log level will print:
#'
#' * Logger$logTrace("Foo")
#' * Logger$logDebug("Foo")
#' * Logger$logInfo("Foo")
#' * Logger$logWarn("Foo")
#' * Logger$logError("Foo")
#' * Logger$logAlert("Foo")
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param msg
#' * The message to log (can be a data object like a data.frame, matrix, or vector)
#'    * Default: none
#'
#' @param data
#' * An optional data object like a data.frame, matrix, or vector that you want to print along with a message from the msg param
#'    * Default: NULL
#'
#' @param context
#' * Additional information to add to the log output to help indicate where the message is coming from in the code.
#'    * Default: {the environment/package the logger is defined in. Also, if it can be found, the source file and line number of the caller will be listed.}
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#' **nothing: prints a log message**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'   # set loglevel to TRACE to show all messages
#'   Logger$setLogLevel('TRACE')
#'
#'   # Log some messages
#'   Logger$logTrace("Foo Trace")
#'   Logger$logDebug("Foo Debug")
#'   Logger$logInfo("Foo Info")
#'   Logger$logWarn("Foo Warn")
#'   Logger$logError("Foo Error")
#'   Logger$logAlert("Foo Alert")
#'
#'   # With Data Output
#'   Logger$logInfo("----------Start -----------")
#'   Logger$logInfo( head(iris,5) )
#'   Logger$logInfo( "IRIS:", head(iris,5) )
#'   Logger$logInfo( msg = "IRIS:", data = head(iris,5) )
#'   Logger$logInfo( data = head(iris,5) )
#'   Logger$logInfo("----------Finish -----------")
#'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
LoggerClass <- R6::R6Class(
  "Logger",
  portable = TRUE,
  private  = list(
    ENVNAME        = NULL,
    DATA           = list(),
    DATA_ID_NEXT   = 1,
    add_data_point = function(datapoint) {
      if (is.matrix(datapoint) || is.data.frame(datapoint) || tibble::is_tibble(datapoint) || length(datapoint) > 1) {
        data_id                 <- sprintf("DP%04i", private$DATA_ID_NEXT)
        private$DATA_ID_NEXT    <- private$DATA_ID_NEXT + 1
        if (private$DATA_ID_NEXT > 9999) {
          private$DATA_ID_NEXT <- 1
        }
        private$DATA[[data_id]] <- datapoint

        dlen <- length(private$DATA)
        if (dlen > self$DATAPOINTS) {
          x            <- self$DATAPOINTS
          start        <- (1 + dlen - x)
          private$DATA <- private$DATA[start:dlen]
        }

        return(data_id)
      }
      return("")
    }
  ),
  public   = list(
    # Public Variables
    DATAPOINTS                  = 20,
    LEVELS                      = list(TRACE = 1, DEBUG = 2, INFO = 3, WARN = 4, ERROR = 5, ALERT = 6, OFF = 7),
    LOG_LEVEL                   = 1, # TRACE = 1
    FORMAT                      = "[ %s | %-5.5s | %-40.40s ]: %s",
    TIMESTAMP_FMT               = "%Y-%m-%d %H:%M:%OS3",
    NAME                        = "Logger",
    MAXPRINT                    = 4999,
    MAXPRINTROWS                = 100,
    COLORIZE                    = TRUE,
    COLORIZERS                  = list(TRACE = crayon::green, DEBUG = crayon::silver, INFO = crayon::white, WARN = crayon::yellow, ERROR = crayon::red, ALERT = function(x) {
      crayon::bgRed(crayon::yellow(x))
    }, OFF = NULL),
    OUTPUTS                     = list(),

    # Public Methods
    log                         = function(msg, data = NULL, context = "", level = self$LEVELS$INFO, colorizer = self$COLORIZERS[[level]]) {
      stopifnot(is.numeric(level))


      if (level >= self$LOG_LEVEL) {
        if (missing(msg)) {
          msg <- ""
        }

        # Build/Expand context
        context <- self$build_logger_context(context)

        # Retain for formatting below
        orig_msg <- msg

        # Build 'Msg' Portion of  log message
        if ((!is.character(msg) && !is.numeric(msg)) || is.matrix(msg) || is.data.frame(msg) || (is.vector(msg) && length(msg) > 1)) {
          msg <- to_log_string(object = msg, max_print = self$MAXPRINT, max_print_data_rows = self$MAXPRINTROWS)
        }
        msg <- flatten(msg)

        # Capture a Data ID # if msg is a trackable DATAPOINT
        msg_data         <- ""
        data_is_from_msg <- FALSE
        if (is_set(data)) {
          data_id          <- trim_to_empty(private$add_data_point(data))
          msg_data         <- remove_newlines_from_start_and_end(to_log_string(object = data, max_print = self$MAXPRINT, max_print_data_rows = self$MAXPRINTROWS))
          data_is_from_msg <- FALSE
          if (is_blank(data_id)) {
            data_id <- trim_to_empty(private$add_data_point(orig_msg))
          }
        } else {
          data_id          <- trim_to_empty(private$add_data_point(orig_msg))
          msg_data         <- ""
          data_is_from_msg <- TRUE
        }

        # Add 'DATAPOINT ID' to 'msg' portion of log message if present
        if (nchar(data_id) > 0) {
          if (data_is_from_msg) {
            if (is_blank(msg_data)) {
              msg <- sprintf("%s\n\n%s\n", data_id, msg)
            } else {
              msg <- sprintf("%s\n\n%s\n\n%s\n", data_id, msg, msg_data)
            }
          } else {
            if (is_blank(msg)) {
              msg <- sprintf("%s\n\n%s\n", data_id, msg_data)
            } else {
              msg <- sprintf("%s\n\n%s\n\n%s\n", data_id, msg, msg_data)
            }
          }
        } else {
          if (is_not_blank(msg_data)) {
            msg <- sprintf("%s\n\n%s\n\n%s\n", data_id, msg, msg_data)
          }
        }
        msg <- indent_multiline_message(msg)

        output <- sprintf(
          self$FORMAT,
          format(Sys.time(), self$TIMESTAMP_FMT),
          names(self$LEVELS)[level],
          context,
          msg
        )

        if (self$COLORIZE && !is.null(colorizer)) {
          output <- colorizer(output)
        }

        print_long_output(output, max_print = self$MAXPRINT, connections = self$OUTPUTS)
      }
    },
    build_logger_context        = function(context) {
      #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      # Build 'Context' Portion of log message
      #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      # pull the context width out of the format string so we don't hardcode it here
      fmt         <- trimws(unlist(strsplit(gsub("[^a-zA-Z0-9\\.%\\-]", "", self$FORMAT), "%")), "both")
      ctxfmt      <- fmt[4]
      ctxalign    <- gsub("(-*)(\\d+)\\.*(\\d*).*", "\\1", ctxfmt, perl = TRUE)
      maxCtxWidth <- gsub("(-*)(\\d+)\\.*(\\d*).*", "\\2", ctxfmt, perl = TRUE)


      # Prepend environment info if available
      if (is_not_blank(private$ENVNAME)) {
        context <- trim_to_empty(sprintf("%s:%s %s", private$ENVNAME, self$NAME, context))
      } else {
        context <- trim_to_empty(sprintf("%s %s", self$NAME, context))
      }

      # Find the source file and line number where log message originated
      atSrc <- trim_to_empty(find_line_number_of_calling_method(".*(\\$log[TDIWEA]|\\$setLogLevel|print_stack_trace).*"))
      if (is.null(atSrc)) {
        atSrc <- " "
      }

      if (length(maxCtxWidth) > 0 && grepl("[0-9]+", maxCtxWidth)) {
        maxCtxWidth <- as.integer(maxCtxWidth)
      } else {
        maxCtxWidth <- 0
      }

      output <- ""

      if (maxCtxWidth > 0) {

        # Add line number if present
        if (nchar(output) > 0) {
          output <- sprintf("%s | %s", atSrc, output)
        } else {
          output <- sprintf("%s", atSrc)
        }

        # Trim context or right-pad to remaining width
        outWidth      <- nchar(output)
        tmpAvailWidth <- maxCtxWidth - outWidth - 3 # -3 for the ' | '
        if (tmpAvailWidth > 0) {
          ctxWidth   <- nchar(context)
          availWidth <- tmpAvailWidth - ctxWidth
          if (availWidth > 0) {
            context <- sprintf("%s%s", context, paste0(rep(" ", availWidth), collapse = ""))
          } else {
            context <- substr(context, ctxWidth - tmpAvailWidth + availWidth + 1, ctxWidth)
          }
        }

        # Add context if present
        if (nchar(output) > 0) {
          output <- sprintf("%s | %s", context, output)
        } else {
          output <- sprintf("%s | ", context)
        }
        # Trim to maxCtxWidth or expand
        outWidth   <- nchar(output)
        availWidth <- maxCtxWidth - outWidth
        if (availWidth > 0) {
          context <- sprintf("%s%s", paste0(rep(" ", availWidth), collapse = ""), output)
        } else {
          context <- substr(output, outWidth - maxCtxWidth + 1, outWidth)
        }
      } else {
        context <- ""
      }

      return(context)
    },
    initialize                  = function(name = "Logger", env_name = environmentName(environment())) {
      self$NAME       <- name
      private$ENVNAME <- env_name
    },
    logTrace                    = function(msg, data = NULL, context = "") {
      self$log(msg, context = context, level = self$LEVELS$TRACE, data = data)
    },
    logDebug                    = function(msg, data = NULL, context = "") {
      self$log(msg, context = context, level = self$LEVELS$DEBUG, data = data)
    },
    logInfo                     = function(msg, data = NULL, context = "") {
      self$log(msg, context = context, level = self$LEVELS$INFO, data = data)
    },
    logWarn                     = function(msg, data = NULL, context = "") {
      self$log(msg, context = context, level = self$LEVELS$WARN, data = data)
    },
    logWarning                  = function(msg, data = NULL, context = "") {
      self$log(msg, context = context, level = self$LEVELS$WARN, data = data)
    },
    logError                    = function(msg, data = NULL, context = "") {
      self$log(msg, context = context, level = self$LEVELS$ERROR, data = data)
    },
    logAlert                    = function(msg, data = NULL, context = "") {
      self$log(msg, context = context, level = self$LEVELS$ALERT, data = data)
    },
    setLogLevel                 = function(level) {
      if (is.character(level)) {
        level <- toupper(level)
        level <- switch(level,
                        "TRACE"   = self$LEVELS$TRACE,
                        "DEBUG"   = self$LEVELS$DEBUG,
                        "INFO"    = self$LEVELS$INFO,
                        "WARN"    = self$LEVELS$WARN,
                        "WARNING" = self$LEVELS$WARN,
                        "ERROR"   = self$LEVELS$ERROR,
                        "ALERT"   = self$LEVELS$ALERT,
                        "OFF"     = self$LEVELS$OFF
        )
      }
      stopifnot(is.numeric(level))
      stopifnot(level %in% self$LEVELS)
      self$LOG_LEVEL <- level
      self$log(sprintf("Note: Logger$setLogLevel( Logger$LEVELS$%s ) called.", names(self$LEVELS[level])), level = self$LEVELS$TRACE)
      return(invisible(self))
    },
    getDataPoint                = function(dataPointId) {
      value <- private$DATA[[dataPointId]]
      if (is.null(value)) {
        self$logWarn(gfmt("\nData Point ['{dataPointId}'] is no longer cached.\nThe current cache size is Logger$DATAPOINTS = {self$DATAPOINTS}.\nIncrease this value if you need a larger cache."))
        return(invisible(NULL))
      }
      return(value)
    },
    loadDataPointsIntoGlobalEnv = function(prefix) {
      if (missing(prefix)) {
        stop("`prefix` is a required value to prefix variables with.")
      }
      for (name in names(private$DATA)) {
        assign(sprintf("%s_%s", prefix, name), private$DATA[[name]], envir = globalenv())
      }
    },
    setFormatContextWidth       = function(width = 40) {
      if (width <= 0) {
        stop("width must be > 0.")
      }
      self$FORMAT <- gfmt("[ %s | %-5.5s | %-{width}.{width}s ]: %s")
    },
    startLogFile                = function(key, filepath) {
      if (!is.null(self$OUTPUTS[[key]])) {
        stop("Already logging to log file with key('", key, "') at file('", filepath, "').")
      }
      self$OUTPUTS[[key]] <- file(description = filepath, open = "at")
    },
    endLogFile                  = function(key) {
      if (is.null(self$OUTPUTS[[key]])) {
        stop("No log file with key('", key, "') exists, cannot end log.")
      }
      theFileConn         <- self$OUTPUTS[[key]]
      self$OUTPUTS[[key]] <- NULL
      flush(theFileConn)
      close(theFileConn)
    }
  )
)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Loggers <- new.env()
# Loggers$ALL <- c()
# Loggers$set_all_log_levels <- function(log_level, verbose = TRUE){
#     for (i in 1:length(Loggers$ALL) ) {
#         logger <- Loggers$ALL[[i]]
#         logger$setLogLevel(log_level)
#     }
# }
# Loggers$print_names <- function(){
#     for (i in 1:length(Loggers$ALL) ) {
#         logger <- Loggers$ALL[[i]]
#         message(sprintf("Logger[%03i]: %s", i, logger$NAME ))
#     }
# }
# Loggers$get_logger <- function(index){
#     logger <- Loggers$ALL[index]
#     return(logger)
# }

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @rdname create_logger
#' @name   create_logger
#' @title  create_logger
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @description Creates a custom logger for use by other packages to provide different default context information. By default appgen will find its own internal Logger instance, so this function is not strictly required to be called.
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#'
#' @param defaultLogLevel
#' * The default level to set the logger to
#'    * Default: 'DEBUG'
#'
#' @param name
#' * The name of the Logger.  Will be used in the CONTEXT portion of the log message if no other info is provided.
#'    * Default: 'Logger'
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @section Returns:
#'  **A new Logger Instance**
#'
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @examples
#'
#'   # set loglevel to TRACE to show all messages
#'   ModuleLogger  <- create_logger(name = "MODULE", defaultLogLevel = "INFO")
#'   FrisbeeLogger <- create_logger(name = "Frisbee", defaultLogLevel = "TRACE")
#'
#'   # Log some messages
#'   ModuleLogger$logWarn("Foo Warn on Module Logger")
#'   FrisbeeLogger$logDebug("Foo Debug on Frisbee Logger")
#'
#'
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
create_logger <- function(defaultLogLevel = "debug", name = "Logger", env_name = environmentName(sys.frame(which = -1L))) {
  logger <- LoggerClass$new(name = name, env_name = env_name)
  logger$setLogLevel(defaultLogLevel)

  # Loggers$ALL <- c(Loggers$ALL,logger)

  return(logger)
}



UNIQUE_IDS               <- new.env()
UNIQUE_IDS$values        <- c()
UNIQUE_IDS$add_unique_id <- function(id) {
  UNIQUE_IDS$values <- c(UNIQUE_IDS$values, id)
}
UNIQUE_IDS$clear_values  <- function(id) {
  UNIQUE_IDS$values <- c()
}

#' @export
create_unique_id <- function(type = "widget") {
  # abs(ceiling(rnorm(1) * 1e8)))
  id <- NULL
  while (is.null(id) || id %in% UNIQUE_IDS$values) {
    id <- sprintf("%s_%s", type, toupper(paste(sprintf("%x", as.integer(runif(4, 1111111, 9999999))), collapse = "")))
    id <- gsub("\\s", "_", id)
  }
  UNIQUE_IDS$add_unique_id(id)
  if (length(UNIQUE_IDS$values) > 10000) {
    UNIQUE_IDS$clear_values()
  }

  return(id)
}
