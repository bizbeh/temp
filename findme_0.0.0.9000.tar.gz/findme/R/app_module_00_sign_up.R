
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
sign_up_panel_seq <- list(
    Panel_01 = list(index = 1, previous_tab = NULL, next_tab = "Panel_02", btn_caption = "User information"),
    Panel_02 = list(index = 2, previous_tab = "Panel_01", next_tab = "FINISH", btn_caption = "Preview")
)
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
sign_up_wizard_module <- create_module_definition(
    name  = "sign_up_wizard_module",
    title = "Sign up Wizard",
    model_factory = function() {
        model <- create_model_instance(
            name       = "SIGNUPWIZSUB",
            properties = list(
                modules = list(
                    panel_meta_information         = as_not_loggable(sign_up_meta_information$new())#,
                    #panel_preview                  = as_not_loggable(scenario_builder_preview$new())
                )
            )
        )
        return(model)
    },
    ui = function(self, ns, model, ...) {
        args <- list(...)
        panel <- ScrollFitDiv(
            style = "padding: 2px; width: 100%;",
            shiny::tabsetPanel(
                id = "wiz_tabs_wizard",
                shiny::tabPanel("Panel_01", model$modules$panel_meta_information$ui())#,
                #shiny::tabPanel("Panel_02", model$modules$panel_preview$ui())
            ),
            shiny::tags$style("#wiz_tabs_wizard.nav-tabs { display: none; }")
        )
        return(panel)
    },
    #%%%%%%%%%%%%[source tree divider]%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    #:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: ----
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    server        = function(input, output, session, context, app_model, model, ...) {
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # Sub-Modules: Details ----
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        model$modules$panel_meta_information$server(input = input, output = output, session = session, context = context)
        #model$modules$panel_preview$server(input = input, output = output, session = session, context = context)
        #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        #+++++ ----
        # Server: global listeners: ----
        #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        # |--> MAIN Dialog opened: ----
        shiny::observeEvent(input$dialog_sign_up_back, protect({
            sign_up_wizard_module$static$on_main_dialog_select_tab_panel(context = context, tab_name = "Panel_01", is_next_direction = FALSE)
        }))
        # |--> MAIN Dialog Next: ----
        shiny::observeEvent(input$dialog_sign_up_next, protect({
            sign_up_wizard_module$static$on_main_dialog_select_tab_panel(context = context, tab_name = "Panel_02", is_next_direction = TRUE)
        }))

        # |--> MAIN Dialog FINISH: ----
        shiny::observeEvent(input$dialog_sign_up_close, protect({
            sign_up_wizard_module$static$on_main_dialog_finish_button_clicked(context)
        }))

        # |--> MAIIN Dialog Cancel: ----
        shiny::observeEvent(input[["dialog_sign_up_cancel"]],
                            {
                                protect({
            shiny::removeModal()
            #context$app_model$WIZARD$init()
        })})


        # |--> SAVE SCENARIO INFO CHANGES: ----
        observe({
        })

    }
)
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#............................................... ----
# UI Helper Functions ----
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#............................................... ----
# Scenario creation begin end Helpers ----
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sign_up_wizard_module$static$on_main_dialog_finish_button_clicked <- function(context){
    input <- context$input
    output <- context$output
    session <- context$session


}


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

sign_up_wizard_module$static$open_dialog <- function(context, wiz_panel, title = "Sign up") {

    shinyjs::delay(ms = 100, {
        shiny::withProgress(
            min = 1, max = 100, value = 100, message = "Loading meta data...",
            expr = {
                sign_up_wizard_module$static$on_main_dialog_select_tab_panel(context = context, tab_name = "Panel_01")
            })
    })
    open_panel_as_dialog(
        title   = title,
        panel   = wiz_panel,
        width   = 600,
        height  = 800,
        buttons = FormLayout(
            fillwidth = "100%",
            FormRow(
                FormCell(
                    valign = "middle",
                    fillwidth = "auto",
                    shiny::actionButton("dialog_sign_up_cancel",  "Cancel")
                ),
                FormCell(
                    valign = "middle",
                    fillwidth = "100%",
                    shiny::tags$span(style = "width: 100%;")
                ),
                FormCell(
                    valign = "middle",
                    fillwidth = "auto",
                    style = "padding-right: 5px;",
                    shiny::actionButton("dialog_sign_up_back", label = "User info", icon = shiny::icon("chevron-left"))
                ),
                FormCell(
                    valign = "middle",
                    fillwidth = "auto",
                    style = "padding-right: 10px;",
                    shiny::actionButton("dialog_sign_up_next",    label = shiny::tags$span("Preview", shiny::icon("chevron-right")))
                ),
                FormCell(
                    valign = "middle",
                    fillwidth = "auto",
                    style = "padding-right: 10px;",
                    shinyjs::hidden(shiny::actionButton("dialog_sign_up_close",    label = shiny::tags$span("Sign up", shiny::icon("chevron-right")))
                    ))
            )
        )
    )
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
sign_up_wizard_module$static$on_pss_dialog_cancel_button_clicked <- function(context) {
    shiny::removeModal()
    context$app_model$GEO$WIZARD_SCENARIO$init()
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#............................................... ----
# sign up panel navigation Helpers ----
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
sign_up_wizard_module$static$on_main_dialog_select_tab_panel <- function(context, tab_name, is_next_direction = FALSE, pre_check_needed = TRUE) {
    input <- context$input
    #GEO   <- context$app_model$GEO
    if (tab_name != "FINISH") {
        if (is_next_direction) {

            tab_info <- sign_up_panel_seq[[tab_name]]
            prev_tab_info <- sign_up_panel_seq[[tab_info$previous_tab]]
            #msgs <- GEO$WIZARD_SCENARIO$validate_wizard_selections(tab_index = prev_tab_info$index)
            if (length(msgs) > 0) {
                shiny_alert(title = "Validation", message = paste0(msgs, collapse = "\n"))
                return(invisible(NULL))
            }
        }
        shiny::updateTabsetPanel(session = context$session, inputId = "wiz_tabs_wizard", selected = tab_name)
        #GEO$WIZARD_SCENARIO$selected_tab <- tab_name
        previous_tab <- sign_up_panel_seq[[tab_name]]$previous_tab
        next_tab <- sign_up_panel_seq[[tab_name]]$next_tab
        previous_btn_caption <- ifelse(is.null(previous_tab), "", paste0(" ", sign_up_panel_seq[[previous_tab]]$btn_caption))
        next_btn_caption <- ifelse(next_tab == "FINISH", "Sign up", paste0(" ", sign_up_panel_seq[[next_tab]]$btn_caption))

        if (is.null(next_btn_caption)) {
            next_btn_caption <- ""
        }else{
            next_btn_caption <- paste0(next_btn_caption, " ")
        }
        shinyjs::hide("dialog_sign_up_close")
        switch(
            tab_name,
            "Panel_02" = {
                if (is_next_direction) {
                    shiny::withProgress(
                        min = 1, max = 100, value = 100, message = "Loading Countries...",
                        expr = {
                            # scenario_builder_meta_information$static$update_country_list(context)
                            # scenario_builder_country_selection$static$init_countries(context)
                        })
                }
            }
        )
        if (next_btn_caption != "Sign up ") {
            next_btn_caption <- paste0('<span>',
                                       next_btn_caption,
                                       '<i class="fa fa-chevron-right" role="presentation" aria-label="chevron-right icon"></i>',
                                       '</span>')
        }
        shiny::updateActionButton(inputId = "dialog_sign_up_next", label = next_btn_caption)
        if (previous_btn_caption == "") {
            shinyjs::hide("dialog_sign_up_back")
        } else {
            shinyjs::show("dialog_sign_up_back")
            shiny::updateActionButton(inputId = "dialog_sign_up_back", label = previous_btn_caption, icon = shiny::icon("chevron-left"))
        }
        shinyjs::show("dialog_sign_up_cancel")
    }else{
        #sign_up_wizard_module$static$on_main_dialog_submit_button_clicked(context)
    }
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
sign_up_wizard_module$static$switch_footer_buttons <- function(keep_main_buttons = TRUE) {
    if (keep_main_buttons) {
        shinyjs::enable("dialog_sign_up_cancel")
        shinyjs::enable("dialog_sign_up_back")
        shinyjs::enable("dialog_sign_up_next")
    }else{
        shinyjs::disable("dialog_sign_up_cancel")
        shinyjs::disable("dialog_sign_up_back")
        shinyjs::disable("dialog_sign_up_next")
    }
}
