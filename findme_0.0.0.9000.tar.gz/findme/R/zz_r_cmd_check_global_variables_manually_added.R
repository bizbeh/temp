##########################################################################################################################################################################
#
# The purpose of this file is to setup globalVariable() defs that tell
#    R CMD CHECK that Non-Standard-Evaluation (NSE) variables used in dplyr
#    code are ok and valid and not to generate a NOTE for it.
#
#      R Reference:
#        See: https://rdrr.io/r/utils/globalVariables.html
#
#      Hadley Reference:
#        See: https://r-pkgs.org/r-cmd-check.html#check-checks
#           Scan page for: '?globalVariables'
#        Some related historical refs:
#           https://stackoverflow.com/questions/9439256/how-can-i-handle-r-cmd-check-no-visible-binding-for-global-variable-notes-when#comment20826625_12429344
#           https://stackoverflow.com/questions/9439256/how-can-i-handle-r-cmd-check-no-visible-binding-for-global-variable-notes-when#comment43863146_12429344
##########################################################################################################################################################################

#############################################################################
# R CMD Check Globals For: R6
utils::globalVariables(
    package = "findme",
    names   = c(
        "self"
    )
)
