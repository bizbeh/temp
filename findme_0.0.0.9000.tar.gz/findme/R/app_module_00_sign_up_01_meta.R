#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%|
#' @description
#'    Shiny Module to define meta data for sign up
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++|
#' @section Returns:
#' \preformatted{
#'
#'    **Shinygen Module**
#'
#' }
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++|
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++|
#' @title  sign_up_meta_information
#' @rdname sign_up_meta_information
#' @name   sign_up_meta_information
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%|
sign_up_meta_information <- create_module_definition(
    name   = "sign_up_meta_information",
    title  = "sign_up_meta_information",
    #%%%%%%%%%%%%[source tree divider]%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    #:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: ----
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ui     = function(self, ns, model, ...) {
        mandatory_element <- function(label){shiny::tags$span(label, shiny::tags$span(style = 'color:red;', "*"))}
        panel <- FormLayout(
            fillwidth  = "100%",
            fillheight = sprintf("%spx", 700 - 140),
            FormRow(
                FormCell(
                    colspan = 4,
                    fillwidth = "100%",
                    section_title(id = "wiz_meta_html_scenario_info",
                                  title = "user information :")
                )
            ),
            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            # UI :Scenario Parameter : ----
            #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            FormRow(
                FormCell(
                    valign = "middle",
                    colspan = 2,
                    shiny::h3(mandatory_element("Name"))),
                FormCell(
                    valign = "middle",
                    colspan = 2,
                    shiny::textInput(inputId = "sign_up_name",
                                     label = ""))
            )
        )
        return(panel)
    },
    #%%%%%%%%%%%%[source tree divider]%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    #:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: ----
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    server = function(input, output, session, context, ...) {

    }
)
