#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Helper Function to hide R6'iness ----
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
create_model_instance <- function(name, submodels = list(), properties = list(), functions = list(), reactives = list(), log_level = "TRACE" ){
    theModel <- SgModel$create(
        model_name = name,
        submodels  = submodels,
        properties = properties,
        functions  = functions,
        reactives  = reactives,
        log_level  = log_level
    )
    return(theModel)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
create_model_factory <- function(name, submodels = list(), properties = list(), functions = list(), reactives = list(), log_level = "TRACE" ){
    return(function(){
        create_model_instance(
            name       = name,
            submodels  = submodels,
            properties = properties,
            functions  = functions,
            reactives  = reactives,
            log_level  = log_level
        )
    })
}




#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ViewModel <- R6::R6Class("ViewModel", portable = TRUE)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ViewModel$create <- function(model_name, submodels = list(), properties = list(), functions = list(), reactives = list(), log_level = "TRACE") {

    depMsg     = ""
    depMsg     = c(depMsg, "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    depMsg     = c(depMsg, "\nDEPRECATED SYNTAX:")
    depMsg     = c(depMsg, "\n")
    depMsg     = c(depMsg, "\n    ViewModel$create(model_name = '",model_name,"', properties = list(...), ... )")
    depMsg     = c(depMsg, "\n")
    depMsg     = c(depMsg, "\nPLEASE USE NEW SYNTAX:")
    depMsg     = c(depMsg, "\n")
    depMsg     = c(depMsg, "\n    shinygen::create_model_instance(name = '",model_name,"', properties = list(...),  ... )")
    depMsg     = c(depMsg, "\n")
    depMsg     = c(depMsg, "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    depMsg     = c(depMsg, "\n")

    warning(depMsg, immediate. = TRUE)
    Sys.sleep(.5)

    theModel <- SgModel$create(
        model_name = model_name,
        submodels  = submodels,
        properties = properties,
        functions  = functions,
        reactives  = reactives,
        log_level  = log_level
    )
    return(theModel)
}


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SgModel   <- R6::R6Class(
    "SgModel", portable = TRUE, inherit = ViewModel,

    private = list(
        myInstanceId = create_unique_id(type="model"),
        myContext    = list(input = NA, output = NA, session = NA, modules = NA, app_model = NA, other = list()) ,
        myEvents     = NULL,
        myAutoFire   = NULL,
        myProperties = NULL,
        mySubModels  = NULL,

        getModelName = function(){
            return(class(self)[[1]])
        },

        fireEvent = function(propertyName) {
            theValue <- isolate({
                theEvent <- private$myEvents[[propertyName]]
                if (!is.null(theEvent)) {
                    private$myEvents[[propertyName]] <- private$myEvents[[propertyName]] + 1
                    self$Logger$logDebug(gfmt("Event Fired: '{propertyName}_changed'.  Event Count: '{private$myEvents[[propertyName]]:05d}'."))
                    private$myEvents[[propertyName]]
                } else {
                    self$Logger$logWarn(gfmt("Invalid event name '{propertyName}_changed'."))
                }
            })
            return(invisible(theValue))
        },

        getOrSet = function(value, varName, type, collection){
            if (missing(value)) {
                if (!(varName %in% names(collection))) {
                    self$Logger$logWarn(gfmt("Invalid {type} name '{varName}'."))
                    return(NA)
                }
                return(collection[[varName]])
            } else {
                if (!(varName %in% names(collection))) {
                    self$Logger$logWarn(gfmt("Invalid {type} name '{varName}'."))
                    return(invisible(NA))
                } else {
                    property_changed <- !identical(collection[[varName]], value)
                    collection[[varName]] <- value

                    dspValue <- value
                    not_loggable <- !is_loggable(dspValue)
                    if ( tibble::is_tibble(dspValue) ) {
                        dspValue <- as.data.frame(dspValue)
                        # keep track of not_loggable after converting to data.frame
                        if (not_loggable) {
                            dspValue <- as_not_loggable(dspValue)
                        }
                    }

                    if (property_changed && private$myAutoFire[[varName]]) {
                        private$fireEvent(varName)
                    }

                    if ( type != 'model' && property_changed ) {
                        if ( R6::is.R6(value) ) {
                            self$Logger$logTrace(gfmt("'{varName}' {type} set to: '{attr(value,'class')[[1]]}'"))
                        } else {
                            if ( ((is.vector(value) || is.list(value)) && length(value) > 1) || is.data.frame(value) || is.matrix(value) || tibble::is_tibble(value) ) {
                                self$Logger$logTrace( msg = gfmt("'{varName}' {type} set to:"), data = dspValue)
                            } else {
                                dspValue <- to_log_string(dspValue)
                                self$Logger$logTrace(gfmt("'{varName}' {type} set to: '{dspValue}'"))
                            }
                        }
                    }
                    return(invisible(NULL))
                }
            }
        },

        model = function(value, modelName) {
            private$getOrSet(value, modelName, "model", private$mySubModels )
        },

        property = function(value, propertyName) {
            private$getOrSet(value, propertyName, "property", private$myProperties )
        }
    ),

    active = list(
        # This is the wrapper object that contains list( input, output, session, modules, app_model, other)
        context = function(value){
            if( missing(value) ){
                return( private$myContext)
            }else{
                self$setContext(value)
                return(invisible(private$myContext))
            }
        }
    ),

    public = list(
        Logger = NULL,

        # This is the wrapper object that contains list( input, output, session, modules, app_model, other)
        setContext = function(cxt){
            if( SgModel$is_context_set(private$myContext) ){
                msg <- gfmt("{private$getModelName()}$context is read-only once set and it is already set.")
                self$Logger$logError(msg)
                warning(msg)
                return(invisible(NULL))
            }

            self$Logger$logTrace(gfmt("{private$getModelName()} $ context initialized."))
            private$myContext = cxt

            for( p in ls(private$mySubModels) ){
                pval <- private$mySubModels[[p]]
                #self$Logger$logTrace(gfmt("Testing property to see if it is a Model object: '{private$getModelName()}${p}': {paste(class(pval), collapse = ' | ')}."))
                if( is(pval,"Model") ) {
                    if(is.null(pval$context) || !SgModel$is_context_set(pval$context) ){
                        #self$Logger$logTrace(gfmt("Model object not set yet: '{private$getModelName()}${p}'."))
                        pval$setContext(cxt)
                    } else {
                        #self$Logger$logTrace(gfmt("Model object already set: '{private$getModelName()}${p}'."))
                    }
                }
            }

        }

    )

)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SgModel$is_context_set <- function(context) {
    if( is.null(context) || is.na(context)){
        return(FALSE)
    }

    # If the object does not have an 'input' value, then the context is not setup
    if( !("input" %in% names(context) ) || is.null(context$input) || is.na(context$input) ){
        return(FALSE)
    }

    return(TRUE)
}


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SgModel$capture_plot <- function(x) {
    return(function() {
        x
    })
}

SgModel$create <- function(model_name, submodels = list(), properties = list(), functions = list(), reactives = list(), log_level = "TRACE" ){

    #
    # Validate Reactive function signatures
    #
    reactiveSignature <- 'function( input, output, session, modules, app_model, context = list(input = NA, output = NA, session = NA, modules = NA, app_model = NA, other = list()) ) '
    for (name in names(reactives)) {
        ff <- reactives[[name]]
        if( !is.function(ff) || length(formals(ff)) != 6 ){
            stop(gfmt("{model_name} `reactives` list element['{name}'] must be a *6-arg* function with signature: {reactiveSignature}."))
        }
        args <- formals(ff)
        if( !all(c("input", "output", "session", "modules", "app_model","context") %in% names(args)) ){
            stop(gfmt("{model_name} `reactives` list element['{name}'] must be a 6-arg function with *signature*: {reactiveSignature}.  Missing a parameter."))
        }
        contextDef <- eval(args$context)
        if( is.null(contextDef) || !is.list(contextDef) ){
            stop(gfmt("{model_name} `reactives` list element['{name}'] must be a 6-arg function with *signature*: {reactiveSignature}.  Missing 'context' parameter."))
        }
        if( !all( c("input", "output", "session", "modules", "app_model", "other") %in% names(contextDef))){
            stop(gfmt("{model_name} `reactives` list element['{name}'] must be a 6-arg function with *signature*: {reactiveSignature}.  `context` object has wrong elements."))
        }
    }

    # Init submodel logger names
    for (sm in names(submodels)) {
        mm <- submodels[[sm]]
        #prefix child model logger's name with this models name
        tmpLogger <- mm$Logger
        tmpLogger$NAME <- sprintf('%s$%s',model_name, tmpLogger$NAME)
    }
    myEnvName  <- ""; #environmentName(sys.frame(which = -1L))

    as.named.list <- function( x ) {
        x <- as.list(x)
        names(x) <- rep("name", length(x))
        return(x)
    }
    as.name_value.list <- function( x ) {
        result <-list()

        if( length(x) > 0 ){
            for( i in 1:length(x)) {
                name <- names(x)[[i]]
                row <- list( name = name, value = x[[i]])
                result[[i]] <- row
            }
        }
        return(result)
    }

    template_data <- list(
        model_name     = model_name,
        log_level      = log_level,
        myEnvName      = myEnvName,

        submodels      = as.name_value.list(submodels),
        properties     = as.name_value.list(properties),
        functions      = as.name_value.list(functions),
        reactives      = as.name_value.list(reactives)

    )


    template <- paste0(readLines(system.file("code_templates/sg_model_template.R", package = "shinygen")), collapse = "\n")
    text <- whisker::whisker.render(template = template, data = template_data)

    print_model_template <- getOption("shinygen.print.model.template", default = FALSE)
    if ( print_model_template ) {
        message(text)
    }

    TMPCLASS <- eval(expr = parse(text = text))
    ##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    ##  Add user functions and reactives to template class
    ##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    #Functions
    for (name in names(functions)) {
        TMPCLASS$set("public", name, functions[[name]])
    }
    #Reactives
    for (name in names(reactives)) {
        TMPCLASS$set("private", sprintf("reactive_%s",name), reactives[[name]])
    }

    ##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    ##  Instantiate and Initialize
    ##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    myInstance <- TMPCLASS$new()


    #SubModels
    for (name in names(submodels)) {
        myInstance[[name]] <- submodels[[name]]
    }

    #Properties
    for (name in names(properties)) {
        myInstance[[name]] <- properties[[name]]
    }

    myInstance$static <- list()


    return(myInstance)
}




#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Helper Function to hide R6'iness ----
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
create_module_definition <- function( name, title, initialize = NULL, model = NULL, model_factory = NULL, ui = function(self,ns,...){}, server = function(input, output, session, modules, app_model, context, ...){} ){

    theClassname    = name
    theTitle        = title
    theUi           = ui
    theServer       = server
    theInit         = initialize
    theModel        = substitute(model)
    theModelFactory = substitute(model_factory)

    if( is.null(theModelFactory) && !is.null(theModel) ){
        theModelFactory <- function(){return(eval(theModel))}
    }

    # UI function Arguments
    if ( !is.null(ui)) {
        uiArgs <- methods::formalArgs(ui)
        requiredUiArgs <- c("self", "ns", "...")
        allowedUiArgs  <- c("self", "ns", "model", "...")
        for (name in requiredUiArgs) {
            if( !(name %in% uiArgs) ){
                msg <- ""
                msg <- sprintf("%sThe `ui` function is missing argument: `%s`.", msg, name)
                msg <- sprintf("%s\n\tThe function signature *must* have: `ui(%s)`.", msg, paste0(requiredUiArgs, collapse = ", "))
                msg <- sprintf("%s\n\tThe function signature *can* have:  `ui(%s)`.", msg, paste0(allowedUiArgs, collapse = ", "))
                stop(msg)
            }
        }
    }

    # SERVER function Arguments
    if ( !is.null(server)) {
        serverArgs <- methods::formalArgs(server)
        requiredServerArgs <- c("input", "output", "session", "...")
        allowedServerArgs  <- c("input", "output", "session", "context", "modules", "app_model", "model",  "...")
        for (name in requiredServerArgs) {
            if( !(name %in% serverArgs) ){
                msg <- ""
                msg <- sprintf("%sThe `server` function is missing argument: `%s`.", msg, name)
                msg <- sprintf("%s\n\tThe function signature *must* have: `server(%s)`.", msg, paste0(requiredServerArgs, collapse = ", "))
                msg <- sprintf("%s\n\tThe function signature *can* have:  `server(%s)`.", msg, paste0(allowedServerArgs, collapse = ", "))
                stop(msg)
            }
        }
    }

    # INITIALIZE function Arguments
    if ( !is.null(initialize)) {
        initializeArgs <- methods::formalArgs(initialize)
        requiredInitializeArgs <- c("id", "title", "namespaceId", "...")
        allowedInitializeArgs  <- c("id", "title", "namespaceId", "...")
        for (name in requiredInitializeArgs) {
            if( !(name %in% initializeArgs) ){
                msg <- ""
                msg <- sprintf("%sThe `initialize` function is missing argument: `%s`.", msg, name)
                msg <- sprintf("%s\n\tThe function signature *must* have: `initialize(%s)`.", msg, paste0(requiredInitializeArgs, collapse = ", "))
                #msg <- sprintf("%s\n\tThe function signature *can* have:  `initialize(%s)`.", msg, paste0(allowedInitializeArgs, collapse = ", "))
                stop(msg)
            }
        }
    }


    theModule <- R6::R6Class(
        classname = theClassname,
        portable = TRUE,
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # + private ----
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        private = list(
            myClassName      = NULL,
            myNamespaceId    = NULL,
            myId             = NULL,
            myTitle          = NULL,
            myInstanceId     = NULL,

            myUiFunction     = theUi,
            myServerFunction = theServer,
            myInitFunction   = theInit,
            myModelFactory   = theModelFactory,


            myAppModel       = NULL,
            myModel          = NULL,
            myModules        = NULL,
            myContext        = NULL
        ),

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # + active ----
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        active = list(

            instanceId = function(value){
                if (missing(value)) {
                    return(private$myInstanceId)
                } else {
                    stop(sprintf("`%s$instanceId` is readonly", private$myClassName), call. = FALSE)
                }
            },

            namespaceId = function(value){
                if (missing(value)) {
                    return(private$myNamespaceId)
                } else {
                    stop(sprintf("`%s$namespaceId` is readonly", private$myClassName), call. = FALSE)
                }
            },

            id = function(value){
                if (missing(value)) {
                    return(private$myId)
                }else{
                    stop(sprintf("`%s$Id` is readonly", private$myClassName), call. = FALSE)
                }
            },

            title = function(value){
                if (missing(value)) {
                    return(private$myTitle)
                }else{
                    assertthat::assert_that(is.character(value), length(value) == 1, msg = sprintf("`%s$title`` must be a character vector of length 1.", private$myClassName))
                    private$myTitle <- value
                }
            },

            model = function(value){
                if (missing(value)) {
                    return(private$myModel)
                }else{
                    stop(sprintf("`%s$model` is readonly", private$myClassName), call. = FALSE)
                }
            }

        ),
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # + public ----
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        public = list(
            Logger = NULL,

            setModelFactory = function( modelFactory ){
                private$myModelFactory <- modelFactory
            },

            setModel = function( model){
                private$myModel <- model
            },

            setAppModel = function( model){
                private$myAppModel <- model
            },

            getAppModel = function(){
                return(private$myAppModel)
            },

            setContext = function( context){
                private$myContext <- context
            },

            setUiFunction = function(ff){
                private$myUiFunction <- ff
                environment(self$ui) <- environment(ff)
            },

            setServerFunction = function(ff){
                private$myServerFunction <- ff
                environment(self$server) <- environment(ff)
            },

            setInitFunction = function(ff){
                private$myInitFunction <- ff
                environment(self$initialize) <- environment(ff)
            },

            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            #++  Initialize Function ----
            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            initialize = function(id = NA_character_, title = theTitle, namespaceId = NA_character_, log_level = "TRACE", verbose = TRUE, ...){

                if ( !is.null(private$myModelFactory) ) {
                    a_model = eval(private$myModelFactory)()
                    self$setModel(a_model)
                }

                private$myInstanceId <- create_unique_id(type="module")

                if( !is.null(private$myInitFunction) ){
                    private$myInitFunction(id = id, title = title, namespaceId = namespaceId, ...)
                }

                private$myClassName <- trimws(class(self)[1],"both")
                ignore <- capture.output({
                    self$Logger <- create_logger(log_level, name = sprintf("%s$Logger",private$myClassName))
                })

                assertthat::assert_that(is.character(id), length(id) == 1,                   msg = sprintf("`%s$new(id)` must be a character vector of length 1.", private$myClassName))
                assertthat::assert_that(is.character(title), length(title) == 1,             msg = sprintf("`%s$new(title)` must be a character vector of length 1.", private$myClassName))
                assertthat::assert_that(is.character(namespaceId), length(namespaceId) == 1, msg = sprintf("`%s$new(namespaceId)` must be a character vector of length 1.", private$myClassName))

                if (is.na(id)) {
                    id <- private$myClassName
                }

                if (is.na(title)) {
                    title <- private$myClassName
                }

                private$myNamespaceId <- gsub("__","_",gsub("[^a-zA-Z0-9]","_", trimws(namespaceId,"both")))
                private$myId          <- gsub("__","_",gsub("[^a-zA-Z0-9]","_", trimws(id,"both")))
                private$myTitle       <- title

                if ( verbose ) {
                    self$log_info( sprintf("Namespaces -- shiny::NS() [namespaces] [%-8.8s] for module: `%s`. Set Logger to DEBUG for details.", ifelse(is.na(private$myNamespaceId),"DISABLED","ENABLED"),private$myClassName ))
                    self$log_debug(sprintf("  |---------> Note: To use shiny namespaces, you must specify a `namespaceId = 'xxx'` in the", private$myClassName))
                    self$log_debug(sprintf("  |--------->       `%s$new()` constructor and use `self$ns(id)` on all ui widgets instead of just `id`.", private$myClassName))
                    self$log_debug(sprintf("  |--------->       `e.g. instead of `shiny::textOutput('username')`, use `shiny::textOutput(self$ns('username'))`.", private$myClassName))
                }
            },

            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            #++  Namespace Function ----
            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            ns = function(id){
                if (is.na(private$myNamespaceId)) {
                    return(id)
                }
                return(shiny::NS(private$myNamespaceId, id))
            },

            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            #++  UI Function ----
            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            ui = function(...){

                if (!is.null(private$myUiFunction)) {
                    thePanel <- private$myUiFunction(self = self, ns = self$ns, model = private$myModel, ...)
                } else {
                    thePanel <- tagList(
                        h2(self$title)
                    )
                }

                return(thePanel)
            },

            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            #++  Server Function ----
            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            server = function(input = NULL, output = NULL, session = NULL, modules = NULL, app_model = NULL, context = NULL, model = NULL, ... ) {
                if (is.null(private$myServerFunction)) {
                    return(invisible(self))
                }

                session   = first_not_nullna(session, shiny::getDefaultReactiveDomain())

                # check if we need to run in namespaced session
                if( is_not_blank(private$myNamespaceId) ) {
                    session <- session$makeScope(private$myNamespaceId)
                }

                if (is.null(context)) {
                    context <- list()
                }


                context$input     = session$input
                context$output    = session$output
                context$session   = session
                context$modules   = first_not_nullna(modules,   private$myModules,  context$modules)
                context$app_model = first_not_nullna(app_model, private$myAppModel, context$app_model)
                context$model     = first_not_nullna(           private$myModel)
                context$other     = list(...)

                if( is.null(private$myAppModel) && !is.null(context$app_model) ){
                    private$myAppModel <- app_model
                }


                # Initialize SgModel$context object
                if ( !is.null(context$app_model) && is(context$app_model, "SgModel") && !SgModel$is_context_set(context$app_model$context) ) {
                    context$app_model$context <- context
                }

                withReactiveDomain(session, {
                    result <- private$myServerFunction(
                        input     = context$input,
                        output    = context$output,
                        session   = context$session,
                        modules   = context$modules,
                        app_model = context$app_model,
                        model     = context$model,
                        context   = context,
                        ...
                    )
                })

                return(invisible(result))

            },

            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            #++  Call Module Function ----
            #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            callModule = function(modules = NULL, app_model = NULL, ...) {
                cname  <- private$myClassName
                ctitle <- private$myTitle

                depMsg     = ""
                depMsg     = c(depMsg, "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
                depMsg     = c(depMsg, "\nDEPRECATED SYNTAX:")
                depMsg     = c(depMsg, "\n")
                depMsg     = c(depMsg, "\n    ",cname,"$callModule(modules = modules, app_model = app_model, ...)")
                depMsg     = c(depMsg, "\n")
                depMsg     = c(depMsg, "\nPLEASE USE NEW SYNTAX:")
                depMsg     = c(depMsg, "\n")
                depMsg     = c(depMsg, "\n    ",cname,"$server(modules = modules, app_model = app_model, ...)")
                depMsg     = c(depMsg, "\n")
                depMsg     = c(depMsg, "\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
                depMsg     = c(depMsg, "\n")

                warning(depMsg, immediate. = TRUE)
                Sys.sleep(1)

                session = getDefaultReactiveDomain()
                self$server(
                    input     = session$input,
                    output    = session$output,
                    session   = session,
                    modules   = first_not_nullna(modules,   private$myModules),
                    app_model = first_not_nullna(app_model, private$myAppModel),
                    model     = private$myModel,
                    ...
                )

                return(self)
            },

            log_trace = function(msg, data = NULL, context = ""){
                self$Logger$log(msg, data = data, context = context, level = self$Logger$LEVELS$TRACE)
            },

            log_debug = function(msg, data = NULL, context = ""){
                self$Logger$log(msg, data = data, context = context, level = self$Logger$LEVELS$DEBUG)
            },

            log_info = function(msg, data = NULL, context = ""){
                self$Logger$log(msg, data = data, context = context, level = self$Logger$LEVELS$INFO)
            },

            log_warn = function(msg, data = NULL, context = ""){
                self$Logger$log(msg, data = data, context = context, level = self$Logger$LEVELS$WARN)
            },

            log_warning = function(msg, data = NULL, context = ""){
                self$Logger$log(msg, data = data, context = context, level = self$Logger$LEVELS$WARN)
            },

            log_error = function(msg, data = NULL, context = ""){
                self$Logger$log(msg, data = data, context = context, level = self$Logger$LEVELS$ERROR)
            }

        )
    )

    theModule$set("public","FACTORY",theModule, overwrite = TRUE)
    theModule$static <- list()

    return(theModule)
}


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
scope_modules_to_session <- function(modules, session, app_model = NULL, context = NULL) {
    if( !is.null(app_model) && !is.null(context)){
        context$app_model <- app_model
    }

    if( is.list(modules)){
        result <- list()
        for (name in names(modules)) {
            module <- modules[[name]]
            result[[name]] <- module$FACTORY$new(id = module$id, title = module$title, namespaceId = module$namespaceId, log_level = module$Logger$LOG_LEVEL, verbose = FALSE)
            if( !is.null(app_model)){
                result[[name]]$setAppModel(app_model)
                module$setAppModel(app_model)
            }
        }
        return(result)
    }else{
        module <- modules
        new.module <- module$FACTORY$new(id = module$id, title = module$title, namespaceId = module$namespaceId, log_level = module$Logger$LOG_LEVEL, verbose = FALSE)
        if( !is.null(app_model)){
            module$setAppModel(app_model)
            new.module$setAppModel(app_model)
        }
        return(new.module)
    }
}


create_layout_manager <- function(){
    lm <- new.env()
    lm$get_layout_css_file <- function(){system.file("htmlwidgets/lib/layout_manager-1.0.0/layout_manager-1.0.0.css",  package = "shinygen")}
    lm$get_layout_js_file  <- function(){system.file("htmlwidgets/lib/layout_manager-1.0.0/layout_manager-1.0.0.js",   package = "shinygen")}
    lm$update_page_layout <- function(){
        shinyjs::runjs("resize_lm_containers();")
    }
    return(lm)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
LayoutManager <- create_layout_manager()

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitDashboardBody <- function(...) {
    body <- shinydashboard::dashboardBody(...)
    body <- ScrollFit(body, scrollfit_y_percent = 100)
    body$children[[1]] <- ScrollFit(body$children[[1]])
    return(body)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitDashboardTabItems <- function(...) {
    return(ScrollFit(shinydashboard::tabItems(...)))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitDashboardTabItem <- function(tabName = NULL, ...) {
    return(ScrollFit(shinydashboard::tabItem(tabName = tabName, ...)))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitTabsetPanel <- function(..., id = NULL, selected = NULL, type = c("tabs", "pills"), position = NULL, style = NULL) {
    type <- match.arg(type)
    tsp <- shiny::tabsetPanel(..., id = id, selected = selected, type = type, position = position)
    tsp <- htmltools::tagAppendAttributes(tsp, style = style)
    tsp <- ScrollFit(tsp)
    tsp$children[[2]] <- ScrollFit(tsp$children[[2]], scrollfit_y_percent = 100)
    return(tsp)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitTabPanel <- function(title, ..., value = title, icon = NULL, style = NULL) {
    tp <- shiny::tabPanel(title = title, ..., value = value, icon = icon)
    tp <- htmltools::tagAppendAttributes(tp, style = style)
    return(ScrollFit(tp))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitNavbarPage <- function(title,
                                ...,
                                id          = NULL,
                                selected    = NULL,
                                position    = c("static-top", "fixed-top", "fixed-bottom"),
                                header      = NULL,
                                footer      = NULL,
                                inverse     = FALSE,
                                collapsible = FALSE,
                                fluid       = TRUE,
                                responsive  = NULL,
                                theme       = NULL,
                                windowTitle = title){

    position <- match.arg(position)

    np <- shiny::navbarPage(title = title,
                            ...,
                            id          = id,
                            selected    = selected,
                            position    = position,
                            header      = header,
                            footer      = footer,
                            inverse     = inverse,
                            collapsible = collapsible,
                            fluid       = fluid,
                            responsive  = responsive,
                            theme       = theme,
                            windowTitle = windowTitle)


    cont <- np[[3]][[2]]

    np[[3]][[2]] <- ScrollFitDiv(ScrollFit(cont$children))

    return(np)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitDiv <- function(...) {
    return(ScrollFit(shiny::tags$div(...)))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitVerticalLayout <- function(..., percents = c(), pixels = c(), style = "", row_style = "") {
    x = list(...)
    use_percents <- FALSE
    if ( length(percents) > 0 ) {
        if (length(percents) != length(x)) {
            stop("When ScrollFitVerticalLayout() `percents` argument is used, it must match the length of the `dots` argument.")
        }
        if (!is.numeric(percents)) {
            stop("When ScrollFitVerticalLayout() `percents` argument is used, all values must be integers, e.g. c(25,25,50).")
        }
        if (!isTRUE(all(percents == floor(percents)))) {
            stop("When ScrollFitVerticalLayout() `percents` argument is used, all values must be integers, e.g. c(25,25,50).")
        }
        total <- sum(percents)
        if ( total != 100 ) {
            stop("When ScrollFitVerticalLayout() `percents` argument is used, the sum of all values must 100. Use 0 for no weight on an element.")
        }
        use_percents <- TRUE
    }

    use_pixels <- FALSE
    if ( length(pixels) > 0 ) {
        if (length(pixels) != length(x)) {
            stop("When ScrollFitVerticalLayout() `pixels` argument is used, it must match the length of the `dots` argument.")
        }
        if (!is.numeric(pixels)) {
            stop("When ScrollFitVerticalLayout() `pixels` argument is used, all values must be integers, e.g. c(25,25,50).")
        }
        if (!isTRUE(all(pixels == floor(pixels)))) {
            stop("When ScrollFitVerticalLayout() `pixels` argument is used, all values must be integers, e.g. c(25,25,50).")
        }
        if( use_percents ){
            stop("When ScrollFitVerticalLayout() `pixels` argument is used, the`percents` argument must be an empty vector, e.g. c().")
        }
        use_pixels <- TRUE
    }

    # Build the individual bootstrap rows
    panels = list()
    for (ridx in 1:length(x)) {
        row <- x[[ridx]]
        if ( use_percents ) {
            pct <- percents[[ridx]]
            col <- ScrollFitY(shiny::column(12, row, style = row_style))
            panels[[ridx]] <- ScrollFitY(htmltools::tags$div(class = "row", col), percent = pct)

        } else if( use_pixels ){
            pix <- pixels[[ridx]]
            col <- ScrollFitY(shiny::column(12, row, style = row_style))
            panels[[ridx]] <- ScrollFitY(htmltools::tags$div(class = "row", col), pixels = pix)

        } else {
            col <- shiny::column(12, row, style = row_style)
            panels[[ridx]] <- htmltools::tags$div(class = "row", col)

        }
    }

    # Build the wrapper div to provide a div around panels to ScrollFit to container size
    panel <- ScrollFit(htmltools::tags$div(style = style, panels))

    return(panel)
}


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitX <- function( widget, percent = NULL ) {
    return( ScrollFit(widget, scrollfit_x = TRUE, scrollfit_y = FALSE, scrollfit_x_percent = percent, scrollfit_y_percent = NULL))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFitY <- function( widget, percent = NULL, pixels = NULL) {
    return( ScrollFit(widget, scrollfit_x = FALSE, scrollfit_y = TRUE, scrollfit_x_percent = NULL, scrollfit_y_percent = percent, scrollfit_y_pixels = pixels))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
ScrollFit <- function(widget, scrollfit_x = TRUE, scrollfit_y = TRUE, scrollfit_x_percent = NULL, scrollfit_y_percent = NULL, scrollfit_y_pixels = NULL) {
    scrollfit_x_percent_class <- ""
    scrollfit_y_percent_class <- ""
    scrollfit_y_pixels_class  <- ""

    if( !is.null(scrollfit_x_percent) ){
        scrollfit_x_percent_class <- gfmt(" lm-scrollfit-x-pct-{scrollfit_x_percent}")
    }
    if( !is.null(scrollfit_y_percent) ){
        scrollfit_y_percent_class <- gfmt(" lm-scrollfit-y-pct-{scrollfit_y_percent}")
    }
    if( !is.null(scrollfit_y_pixels) ){
        scrollfit_y_pixels_class <- gfmt(" lm-scrollfit-y-pix-{scrollfit_y_pixels}")
    }

    if ( scrollfit_x && scrollfit_y ) {
        widget <- private_append_class(widget, gfmt("lm-scrollfit lm-scrollfit-x{scrollfit_x_percent_class} lm-scrollfit-y{scrollfit_y_percent_class}{scrollfit_y_pixels_class}"))
    } else if ( scrollfit_x ) {
        widget <- private_append_class(widget, gfmt("lm-scrollfit lm-scrollfit-x{scrollfit_x_percent_class}"))
    } else {
        widget <- private_append_class(widget, gfmt("lm-scrollfit lm-scrollfit-y{scrollfit_y_percent_class}{scrollfit_y_pixels_class}"))
    }

    return(widget);
}

private_append_class <- function(widget, new_class) {
    if (is.null(new_class) || length(new_class) == 0 || is.na(new_class) ) {
        return(widget)
    }

    orig_widget        <- widget
    widget_has_attribs <- FALSE
    widget_in_one      <- FALSE

    if ( ("attribs" %in% names(widget)) ) {
        widget_has_attribs <- TRUE
    } else {
        if( "attribs" %in% names(widget[[1]])) {
            widget_has_attribs <- TRUE
            widget_in_one      <- TRUE
            widget             <- widget[[1]]
        }
    }
    if ( widget_has_attribs ) {
        current_class <- htmltools::tagGetAttribute(widget,'class')
        htmltools::tagAppendAttributes
        if ( is.null(current_class) ) {
            widget <- htmltools::tagAppendAttributes(widget, class = new_class)
        } else {
            widget <- htmltools::tagAppendAttributes(widget, class = paste(unique(strsplit(paste(new_class, collapse = " ")," ")[[1]]), collapse = " "))
        }

        if ( widget_in_one ){
            orig_widget[[1]] <- widget
            widget <- orig_widget
        }
    } else {
        warning('Unable to append class to widget, no attribs found: ', widget)
    }
    return(widget)
}


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
topBottomLayout <- function(topPanel, bottomPanel, topStyle = "", bottomStyle = ""){
    layout <-
        shiny::fluidRow(
            shiny::verticalLayout(
                shiny::wellPanel(
                    style = topStyle,
                    topPanel
                )
            ),
            shiny::wellPanel(
                style = bottomStyle,
                bottomPanel
            )
        )

    return(layout)

}


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
leftRightLayout <- function(leftPanel, rightPanel, leftPanelWidth = 200, containerStyle = "", leftStyle = "", rightStyle = "", horizontalSpacing = 10){
    layout <-
        htmltools::tagList(
            shinyjs::inlineCSS(rules = list(".right-panel .well .row::after" = "clear:none;")),
            htmltools::tags$div(
                class = "left-right-container ",
                style = sprintf("%s", containerStyle),
                htmltools::tags$div(
                    class = "left-panel",
                    style = sprintf("width: %spx; float: left; height: 100%%; padding: 0px; margin: 0px; display: inline-block;", leftPanelWidth),
                    shiny::wellPanel(
                        style = leftStyle,
                        leftPanel
                    )
                ),
                htmltools::tags$div(
                    class = "right-panel",
                    style = sprintf("margin-left: %spx; padding:0px; height: 100%%; ",(leftPanelWidth + horizontalSpacing)),
                    shiny::wellPanel(
                        style = rightStyle,
                        rightPanel
                    )
                )
            )
        )
    return(layout)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FormLayout <- function(..., fillwidth = "auto", fillheight = "auto", style = "", id = NULL, class = NULL){
    rows <- shiny::tagList(...)
    the_table <-
        shiny::tags$table(
            rows,
            style = gfmt("width: {fillwidth}; height: {fillheight}; {style}")
        )

    if (!is.null(id)) {
        the_table <- shiny::tagAppendAttributes(the_table, "id" = id)
    }
    if (!is.null(class)) {
        the_table <- shiny::tagAppendAttributes(the_table, "class" = class)
    }

    return(the_table)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FormRow <- function(..., id = NULL, class = NULL){
    cells <- shiny::tagList(...)
    #colcount <- 0
    #for(c in cells){
    #    if( "shiny.tag" %in% class(c)){
    #        colcount <- colcount + 1
    #        ss <- c$attribs$style
    #        #print(ss)
    #    }
    #}
    the_tr <- shiny::tags$tr(cells)
    if (!is.null(id)) {
        the_tr <- shiny::tagAppendAttributes(the_tr, "id" = id)
    }
    if (!is.null(class)) {
        the_tr <- shiny::tagAppendAttributes(the_tr, "class" = class)
    }

    return(the_tr)
}


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FormCell <- function(..., colspan = 1, rowspan = 1, valign = c("top","middle","bottom"), halign = c("left","middle","right"), fillwidth = NULL, fillheight = NULL, bgcolor = "transparent", style  = ""){
    valign <- match.arg(valign)
    halign <- match.arg(halign)

    theStyle <- glue::glue("vertical-align: {valign}; text-align: {halign}; background-color: {bgcolor}; {ifelse(is.null(fillwidth),'',paste0('width: ',fillwidth,';'))} {ifelse(is.null(fillheight),'',paste0('height: ',fillheight,';'))} {style}")

    return(
        shiny::tags$td(
            ...,
            colspan = colspan,
            rowspan = rowspan,
            style   = theStyle
        )
    )
}


testFormLayout <- function(){
    FormLayout(
        FormRow(
            FormCell("dogbert"),
            FormCell("catbert")
        ),
        FormRow(
            FormCell("dilbert"),
            FormCell("fennelbert")
        )
    )
}


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitDashboardPage <- function(header, sidebar, body, title = NULL, skin = c("blue", "black", "purple", "green", "red", "yellow"), style = NULL) {
    skin = match.arg(skin)
    dbp <- shinydashboard::dashboardPage(header = header, sidebar = sidebar, body = body, title = title, skin = skin)
    if (!is.null(style)) {
        dbp <- htmltools::tagAppendAttributes(dbp, style = style)
    }

    dbp <- private_append_class(dbp, new_class = "lm-maxfit-absolute")

    wrapper <- dbp[[3]][[1]][[4]][[1]]
    if (wrapper$attribs$class != "wrapper") {
        stop("shiny class hierarchy has changed.....shinygen codefix is needed in MaxFitDashboardPage::wrapper")
    }

    header <- wrapper$children[[1]]
    if (header$attribs$class != "main-header") {
        stop("shiny class hierarchy has changed.....shinygen codefix is needed in MaxFitDashboardPage::main-header")
    }
    #header$attribs$class <- ""

    sidebar <- wrapper$children[[2]]
    if (sidebar$attribs$class != "main-sidebar") {
        stop("shiny class hierarchy has changed.....shinygen codefix is needed in MaxFitDashboardPage::main-sidebar")
    }
    #sidebar$attribs$class <- ""

    content <- wrapper$children[[3]]
    if (content$attribs$class != "content-wrapper") {
        stop("shiny class hierarchy has changed.....shinygen codefix is needed in MaxFitDashboardPage::content-wrapper")
    }
    content$attribs$class <- ""

    # Remove content-wrapper from body to fix absolute layout
    dbp[[3]][[1]][[4]][[1]] <- MaxFitDiv(
        absolute = TRUE,
        shiny::tags$table(
            style = "width:100%; height: 100%; position:absolute; top: 0px; right: 0px; left:0px; bottom: 0px;",
            shiny::tags$tr(
                shiny::tags$td(
                    style = "position: relative; width: 100%; height: auto;",
                    colspan = 2,
                    MaxFitDiv(class = "lm-maxfit-dashboard-header", absolute = FALSE, header)
                )
            ),
            shiny::tags$tr(
                shiny::tags$td(
                    style = "position: relative; height: 100%;",
                    #MaxFitDiv(class = "lm-maxfit-dashboard-sidebar", style = "height: 100%;", absolute = FALSE, sidebar)
                    sidebar %>% shiny::tagAppendAttributes(style = "position: relative;")
                    # MaxFitDiv(
                    #     sidebar,
                    #     MaxFitDiv(content)
                    # )
                ),
                shiny::tags$td(
                    style = "position: relative; height: 100%; width: 100%;",
                    MaxFitDiv(class = "lm-maxfit-dashboard-body", absolute = TRUE, style = "overflow:hidden;", content)
                )
            )
        )
    )

    return(dbp)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitDashboardHeader <- function(..., title = NULL, titleWidth = NULL, disable = FALSE, .list = NULL, style = NULL) {
    dbh <- shinydashboard::dashboardHeader(..., title = title, titleWidth = titleWidth, disable = disable, .list = .list)
    if (!is.null(style)) {
        dbh <- htmltools::tagAppendAttributes(dbh, style = style)
    }

    dbh <- MaxFit(absolute = FALSE, dbh)

    return(dbh)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitDashboardSidebar <- function(..., disable = FALSE, width = NULL, collapsed = FALSE, style = NULL) {
    dbs <- shinydashboard::dashboardSidebar(..., disable = disable, width = width, collapsed = collapsed)
    if (!is.null(style)) {
        dbs <- htmltools::tagAppendAttributes(dbs, style = style)
    }
    dbs <- htmltools::tagAppendAttributes(dbs, style = "padding: 0px!important;")

    return(dbs)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitDashboardBody <- function(..., absolute = TRUE, top = NULL, bottom = NULL, left = NULL, right = NULL) {
    body <- shinydashboard::dashboardBody(...)
    body <- htmltools::tagAppendAttributes(body, style = "margin-left: 0px!important;")

    body <- MaxFit(body, absolute = absolute, top = top, bottom = bottom, left = left, right = right)
    body$children[[1]] <- MaxFit(body$children[[1]])
    return(body)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitDashboardTabItems <- function(..., absolute = TRUE, top = NULL, bottom = NULL, left = NULL, right = NULL) {
    return(MaxFit(shinydashboard::tabItems(...), absolute = absolute, top = top, bottom = bottom, left = left, right = right))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitDashboardTabItem <- function(tabName = NULL, ..., absolute = TRUE, top = NULL, bottom = NULL, left = NULL, right = NULL) {
    return(MaxFit(shinydashboard::tabItem(tabName = tabName, ..., absolute = absolute, top = top, bottom = bottom, left = left, right = right)))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitTabsetPanel <- function(..., id = NULL, selected = NULL, type = c("tabs", "pills"), position = NULL, style = NULL, absolute = TRUE, top = NULL, bottom = NULL, left = NULL, right = NULL) {
    type = match.arg(type)

    tsp <- shiny::tabsetPanel(..., id = id, selected = selected, type = type, position = position)
    if (!is.null(style)){
        tsp <- htmltools::tagAppendAttributes(tsp, style = style)
    }
    tsp <- htmltools::tagAppendAttributes(tsp, style = "padding:0px;")

    tsp$children <- list(
        shiny::tags$table(
            style = "width:100%; height: 100%; position:relative;",
            shiny::tags$tr(
                shiny::tags$td(
                    style = "position: relative; width: 100%; height: auto;",
                    MaxFitDiv(class = "lm-maxfit-tabset-navtabs", absolute = FALSE, tsp$children[[1]])
                )
            ),
            shiny::tags$tr(
                shiny::tags$td(
                    style = "position: relative; width: 100%; height: 100%",
                    MaxFitDiv(class = "lm-maxfit-tabset-tabcontent", MaxFit(tsp$children[[2]]))
                )
            )
        )
    )

    tsp <- MaxFit(tsp, absolute = absolute, top = top, bottom = bottom, left = left, right = right)
    return(tsp)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitTabPanel <- function(title, ..., value = title, icon = NULL, style = NULL, absolute = TRUE, top = NULL, bottom = NULL, left = NULL, right = NULL) {
    tp <- shiny::tabPanel(title = title, ..., value = value, icon = icon)
    if (!is.null(style)) {
        tp <- htmltools::tagAppendAttributes(tp, style = style)
    }
    return(MaxFit(tp, absolute = absolute, top = top, bottom = bottom, left = left, right = right))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitNavbarPage <- function(title,
                             ...,
                             id          = NULL,
                             selected    = NULL,
                             position    = c("static-top", "fixed-top", "fixed-bottom"),
                             header      = NULL,
                             footer      = NULL,
                             inverse     = FALSE,
                             collapsible = FALSE,
                             fluid       = TRUE,
                             responsive  = NULL,
                             theme       = NULL,
                             windowTitle = title,
                             absolute    = TRUE){

    position <- match.arg(position)

    np <- shiny::navbarPage(title = title,
                            ...,
                            id          = id,
                            selected    = selected,
                            position    = position,
                            header      = header,
                            footer      = footer,
                            inverse     = inverse,
                            collapsible = collapsible,
                            fluid       = fluid,
                            responsive  = responsive,
                            theme       = theme,
                            windowTitle = windowTitle)

    # Extract Navigation components out so they become maxfit elements in table
    np[[4]][[1]] <- MaxFitDiv(
        absolute = TRUE,
        shiny::tags$table(
            style = "width:100%; height: 100%; position:relative;",
            shiny::tags$tr(
                shiny::tags$td(
                    style = "position: relative; width: 100%; height: auto;",
                    MaxFitDiv(class = "lm-maxfit-navbar-static", absolute = FALSE, np[[4]][[1]][[1]])
                )
            ),
            shiny::tags$tr(
                shiny::tags$td(
                    style = "position: relative; width: 100%; height: 100%",
                    MaxFitDiv(class = "lm-maxfit-navbarcontent", MaxFit(np[[4]][[1]][[2]]))
                )
            )
        )
    )

    return(np)
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFitDiv <- function(..., absolute = TRUE, top = NULL, bottom = NULL, left = NULL, right = NULL) {
    return(MaxFit(shiny::tags$div(...), absolute = absolute, top = top, bottom = bottom, left = left, right = right))
}

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MaxFit <- function(widget, absolute = TRUE, top = NULL, bottom = NULL, left = NULL, right = NULL) {

    if (absolute) {
        lm_position <- "lm-maxfit-absolute"
    } else {
        lm_position <- "lm-maxfit-relative"
    }
    widget <- private_append_class(widget, gfmt("lm-maxfit {lm_position}"))
    if (absolute) {
        astyle = ""
        if (!is.null(top)) {
            astyle <- c(astyle, sprintf("top: %s%s;", top, ifelse(is.numeric(top),"px","")))
        }
        if (!is.null(bottom)) {
            astyle <- c(astyle, sprintf("bottom: %s%s;", bottom, ifelse(is.numeric(bottom),"px","")))
        }
        if (!is.null(left)) {
            astyle <- c(astyle, sprintf("left: %s%s;", left, ifelse(is.numeric(left),"px","")))
        }
        if (!is.null(right)) {
            astyle <- c(astyle, sprintf("right: %s%s;", right, ifelse(is.numeric(right),"px","")))
        }
        astyle <- stringr::str_squish(paste0(astyle, collapse = " "))
        if (nchar(astyle) > 0) {
            widget <- htmltools::tagAppendAttributes(widget, style = astyle)
        }
    }

    return(widget);
}


MaxFitExample <- function(show_navbar = FALSE) {


    if (show_navbar) {
        ui <- {
            shiny::tagList(
                shinygen::cfda_common(),
                MaxFitNavbarPage(
                    title = "Example MaxFit",
                    MaxFitTabPanel(
                        title = "Tab01",
                        MaxFitDiv(
                            style = "background-color: green; border: 1px solid blue; padding: 5px;",
                            shiny::tags$h3("Tab01 Contents"),
                            shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                            shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                            shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                            shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;")
                        )
                    ),
                    MaxFitTabPanel(
                        title = "Tab02",
                        MaxFitTabsetPanel(
                            MaxFitTabPanel(
                                title = "Tab 2.1",
                                style = "padding: 5px;",
                                shiny::tags$div(style = "background-color: green; border: 1px solid red;", shiny::tags$h3("Tab2.1 Contents")),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;")
                            ),
                            MaxFitTabPanel(
                                title = "Tab 2.2",
                                style = "padding: 5px;",
                                shiny::tags$div(style = "background-color: green; border: 1px solid red;", shiny::tags$h3("Tab2.2 Contents")),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;")
                            )
                        )
                    )
                )
            )
        }
    } else {
        app_title   <- "Example MaxFit"
        ui <- {
            shiny::tagList(
                shinygen::cfda_common(),
                MaxFitDashboardPage(
                    title     = app_title,
                    header    = MaxFitDashboardHeader(
                        title = shinygen::cfda_app_title(
                            tagList(
                                tags$span(style = "font-size:18px;", app_title),
                                tags$span(style = "font-size:9px;",sprintf("( v%s )",  "1.2.3"))
                            )
                        ), titleWidth = "616px"
                    ),

                    sidebar = MaxFitDashboardSidebar(
                        width = "300px",
                        shinydashboard::sidebarMenu(
                            shinydashboard::menuItem( "Tab01",    tabName =  "Tab01",   icon = icon("toggle-on")),
                            shinydashboard::menuItem( "Tab02",    tabName =  "Tab02",   icon = icon("bar-chart"))
                        )
                    ),

                    body = MaxFitDashboardBody(
                        MaxFitDashboardTabItems(
                            MaxFitDashboardTabItem(
                                tabName = "Tab01",
                                # MaxFitDiv(
                                #     style = "padding: 5px; border: 1px solid blue;",
                                shiny::tags$h3("Tab01 Contents"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;")
                                # )
                            ),
                            MaxFitDashboardTabItem(
                                tabName = "Tab02",
                                MaxFitTabsetPanel(
                                    MaxFitTabPanel(
                                        title = "Tab 2.1",
                                        shiny::tags$div(style = "background-color: green; border: 1px solid red;", shiny::tags$h3("Tab2.1 Contents")),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;")
                                    ),
                                    MaxFitTabPanel(
                                        title = "Tab 2.2",
                                        shiny::tags$div(style = "background-color: green; border: 1px solid red;", shiny::tags$h3("Tab2.2 Contents")),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;"),
                                        shiny::tags$div(style="height: 200px; background-color: red; border: 1px solid black;")
                                    )
                                )

                            )
                        )
                    )
                )
            )
        }
    }


    server <- function(input, output, session) {

    }

    shiny::shinyApp(ui, server)


    # MaxFitDashboardPage(header = MaxFitDashboardHeader(), sidebar = MaxFitDashboardSidebar(), body = MaxFitDashboardBody())

}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
new_context <- function(input = NA, output = NA, session = NA, modules = NA, app_model = NA, other = list()){
    context = list(input = input, output = output, session = session, modules = modules, app_model = app_model, other = other)

    return(context)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
assert_is_valid_context <- function(context){
    assertthat::assert_that(!is.null(context))
    assertthat::assert_that(is.list(context))

    required_names <- c("input", "output", "session", "modules", "app_model", "other")
    for (name in required_names) {
        assertthat::assert_that(assertthat::has_name(context, name),     msg = sprintf("`context` is missing the named element: `%s`.",name))
    }

    allowed_names <- c(required_names, "runWithShiny", "model")

    extra_names <- names(context[which(!(names(context) %in% allowed_names))])
    assertthat::assert_that(length(extra_names) == 0, msg = sprintf("`context` has unexpected named element(s): '%s'.", paste0(extra_names, collapse = ", ")))
    invisible(TRUE)
}

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  This function is used only during development inside of RStudio. It switches to {package_name}/inst/application/
#     then invokes shiny on the directory like a real deployment would.
#     Logistically, this is really not testable from testthat.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#' @export
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# nocov start
runShinyApp <- function(
        package_name,                                          # Required the package name for this application
        version                           = NULL,              # The version to run from: inst/application/{version}/app.R to run
        option_shiny_error_handler        = NULL,              # An optional function to call when shiny encounters error (such as: recover)
        option_shiny_max_file_upload_size = "100MB",           # Max file upload size: default shiny option is 5MB
        option_shiny_fullstacktrace       = TRUE,              # whether to show full stackraces or not when shiny encounters error
        option_shiny_trace                = FALSE              # TRUE for all messages, FALSE for none, 'recv' for messages to server, 'send' for messages to client.
) {

    if (is.null(version)) {
        if (fs::dir_exists(package_path("inst/application/master"))) {
            version <- "master"
        } else {
            # legacy app path is  'inst/application/'
            version <- ""
        }
    }

    # load this package's NAMESPACE imports into memory
    import_namespace <- getOption("shinygen.import.package.namespace.imports", default = FALSE)
    if (import_namespace) {
        import_package_namespace_imports(pkgname = package_name, verbose = TRUE)
    }

    # This function is the hook that is called from GEO/inst/application/app.R

    options(warning = 1 ) #Log warnings as soon as they happen
    appDir <- system.file(glue::glue("application/{version}"), package = package_name)
    if( is_blank(appDir)) {
        appDir <- system.file(glue::glue("inst/application/{version}"), package = package_name)
        if( is_blank(appDir)) {
            stop( gfmt("`system.file('application/{version}', package='{package_name}') did not find the '{package_name}/inst/application' directory like it should have. Why???") )
        }
    }
    message(gfmt("Using shiny app dir: {appDir}"))
    setwd(appDir)


    # see https://shiny.rstudio.com/reference/shiny/latest/shiny-options.html
    shiny::shinyOptions(
        appDir               = appDir,
        shiny.maxRequestSize = option_shiny_max_file_upload_size,
        shiny.error          = option_shiny_error_handler,
        shiny.fullstacktrace = option_shiny_fullstacktrace,
        shiny.trace          = option_shiny_trace
    )

    return( shiny::runApp(appDir = appDir) )
}
# nocov end
