#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#
#  General: Read the pre-amble header in
#      master/app.R
#
#  ++++++++++++++++++++++++
#    Deployment Options:
#  ++++++++++++++++++++++++
#
#    OPTION 1:
#
#        ** DEFAULT CHOICE FOR MOST APPS **
#
#        If you only want to manage a single version on RStudio Connect, then just always publish from the master/app.R
#          a. This is likely the default choice for most applications and the most standard choice
#          b. The RsConnect publish metadata will be a subdirectory of that folder, be sure to commit and push it to gitlab
#
#
#    OPTION 2:
#
#        If you want a little more rigor and control around what and where a version is deployed to on RsConnect, and you *want* to manage
#        multiple versions of your app, you can use this option
#
#        a. To help do this, you will need a new folder for each flavor of your app in this folder. You might want to use this naming scheme:
#
#               findme_DEV
#               findme_PROD
#
#        b. See the helper function below for creating these folders.
#            i.   Be aware that if you make customizations to app.R, you need to keep track of merging any changes across releases to the next version.
#            ii.  It's recommended that you always update application/master/** during development, then use the copy function below just before publish.
#            iii. This way, you don't have to update references to shinygen::runShinyApp("findme", version = "master") anywhere.
#
#
#        c. When using this methodology, you will open the app.R file in the versioned folder and click the publish button for that file.
#        d. The RsConnect publish metadata will be a subdirectory of the versioned folder, be sure to commit and push it to gitlab
#
#
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  Helper script to create app folders for each "flavor/version" of your app to maintain
#         (ie this is for option 2 above ... option 1 is perfectly fine too and the default for most apps)
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# make_new_app_flavor <- function() {
#
#     master_folder <- appgen::package_path("inst/application/master")
#
#
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#     # DEV FOLDER
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#     dev_folder    <- appgen::package_path(glue::glue("inst/application/findme_DEV"))
#     fs::dir_copy(master_folder, dev_folder)
#     rstudioapi::navigateToFile(fs::path(dev_folder, "app.R"))
#
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#     # PROD FOLDER
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#     prod_folder    <- appgen::package_path(glue::glue("inst/application/findme_PROD"))
#     fs::dir_copy(master_folder, prod_folder)
#     rstudioapi::navigateToFile(fs::path(prod_folder, "app.R"))
#
# }


