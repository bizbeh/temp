#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%                                                                                                                                               %%%%%%%%
#%%%%%%    R E A D    M E  !!!!!!!     Y E S,   T H I S    M E A N S       Y O U     ! ! ! ! !                                                        %%%%%%%%
#%%%%%%                                                                                                                                               %%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# test_locally_as_real_package_before_publishing_to_rsconnect <- function() {
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#     # HELPER FUNCTION BEFORE PUBLISHING...only meant for you to manually call these during development in RStudio
#     #     This lets you test the application as a real package
#     #     In case you are not aware, running the app via devtools::load_all() is not the same as devtools::load_all() exposes un-exported functions
#     #        so if you have depend on an un-exported function, the devtools::load_all() testing will work fine, but the the run as a real package will fail.
#     #        This helps you find these errors prior to wasting time doing the gitlab ci, install locally, publish to rsconnect, error-out cycle
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
#     # This is how you can run a package-level test before committing to GitLab and waiting for GitLab CI....HOWEVER this version cannot be published to RsConnect
#     appgen::delete_core_dumps()
#     devtools::document();
#     devtools::install_local(appgen::package_path(), dependencies = FALSE, upgrade = FALSE, force = TRUE);
#
#     library(findme);
#     shinygen::runShinyApp("findme", version = "master")
# }

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# install_package_from_drat_before_publishing_to_rsconnect <- function(){
#
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#     # You cannot publish local dev versions...RSConnect needs to find the app in a CRAN like repository (ie.Amgen DRAT repo)
#     #
#     # So you must commit/push your code to gitlab and wait for the PROD CI build to **PASS** so that you have a version of
#     # this package published to DRAT.  You can verify that your build publish to DRAT by browsing for an updated version of your package here:
#     #
#     #          https://dsp01.cfda.amgen.com/repo/drat/dev/src/contrib/
#     #
#     # To deploy to RsConnect, you must have cran or cran-like installed packages RSConnect can find them in private library as it creates
#     #      the packrat bundle to send to to server and then the server will install the package on the RSConnect server from DRAT/CRAN repos
#     #      you installed your packages from (or that already exist in the R System library)
#     #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#     appgen::delete_core_dumps()
#     DRAT_ENV <- "prod" #dev for development or prod for master
#     utils::install.packages('findme', repos = c(glue::glue('https://dsp01.cfda.amgen.com/repo/drat/{DRAT_ENV}'), 'https://cran.rstudio.com'), ignore_repo_cache = TRUE)
#
#     #
#     # NOW .... CLICK the RsConnect publish button in top-right corner of this editor (blue eye-ballish-like icon)
#     #
# }


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%                                                                                                                                               %%%%%%%%
#%%%%%%    A P P     S T A R T S     H E R E                                                                                                          %%%%%%%%
#%%%%%%                                                                                                                                               %%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Add any library statements that you are not fully qualifying your function calls in your app
#
# Adding library statements can also help the RsConnect deploy process find packages it must copy to
#   the RsConnect server. Generally if you use fully qualified functions (ie. pkgname::function_name() )
#   RsConnect can discover all that it needs.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
library(findme)
library(shiny)
library(magrittr)
library(shinyBS)


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# During startup, print the package versions in use...this helps with debugging problems on RsConnect
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
options("width" = 200)
message("\n#########################################################################################################")
print("LibPaths:")
print(.libPaths())
print("\n\n")
print(sessioninfo::session_info())
message("\n#########################################################################################################\n")

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Launch your app
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
app <- findme::create_shiny_app()
shinyApp(app$ui, app$server, enableBookmarking = "server")

