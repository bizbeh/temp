testthat::test_that("R CMD CHECK",{

    # appgen::ioq_req_id("UNIT_999")
    # appgen::ioq_req_description("Check package structure with R CMD check")
    #
    # # Disable file timestamp checking, the time api that devtools uses is broken
    # # https://stat.ethz.ch/pipermail/r-package-devel/2019q1/003578.html
    # Sys.setenv("_R_CHECK_SYSTEM_CLOCK_" = 0)
    #
    # appgen::ioq_test_expect_r_cmd_check_to_be_clean(
    #     check_errors            = TRUE,
    #     check_warnings          = FALSE,
    #     check_notes             = TRUE,
    #     generate_zz_global_vars = TRUE,
    #     check_file_lengths      = FALSE,
    #
    #     allowed_notes_regexes   = c(
    #         ".*checking installed package size.*",
    #         ".*store paths of up to 100 bytes.*",
    #         ".*Importing from so many packages.*"
    #     )
    # )

})

