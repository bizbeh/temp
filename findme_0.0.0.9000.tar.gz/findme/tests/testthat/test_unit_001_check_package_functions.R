#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Enforce snake_case function names and function arg names
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# testthat::test_that("Package Naming Standards",{
#
#     appgen::ioq_req_id("UNIT_001")
#     appgen::ioq_req_description("Check package function naming standards")
#
#     appgen::ioq_test_expect_package_function_naming_standard(
#         testname = "Ensure that all package function names and function args use snake_case and not CamelCase",
#         package_name = "findme"
#     )
#
# })
#
# #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# # Check for possible dplyr variable name bugs
# #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# testthat::test_that("Package Naming Standards",{
#
#     appgen::ioq_req_id("UNIT_001")
#     appgen::ioq_req_description("Check package dplyr functions don't accidentally use same variable name as column name in filter.")
#
#     appgen::ioq_test_expect_dplyr_functions_in_package_to_pass_validation(
#         testname = "Ensure that all dplyr filter functions calls don't mistakenly use a variable name that is the same name as a column name.",
#         package_name = "findme"
#     )
#
# })
#
# #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# # Check for bad function calls....like "browser()"
# #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# test_that("Check Package Functions For Bad Function Calls", {
#
#     appgen::ioq_test_expect_package_functions_do_not_have_common_bugs(
#         testname                         = "Check Package Functions For Bad Function Calls",
#         package_name                     = "findme",
#         skipped_functions                = NULL,
#         allowed_function_call_exceptions = NULL
#     )
#
# })
