library(testthat)
library(findme)
library(shiny)
# library(shinygen)
# library(appgen)
#
# create_and_verify_shiny_test_context <- function(){
#     context <- shinygen::create_shiny_test_context(
#         create_shiny_app_function = findme::create_shiny_app,
#     )
#     return(context)
# }
#
# withShinyTestContext_load_data_file <- function(context, dfPath) {
#     out <- testthat::evaluate_promise({
#         context$runWithShiny({
#             tmp <- UsingModels$load_data_file_from_path(context, dfPath)
#             tmp
#         })
#     })
#     return(out)
# }
