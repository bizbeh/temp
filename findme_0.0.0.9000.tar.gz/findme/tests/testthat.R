###+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
###
### To Run Unit Tests:
###
###  1) Set your current working directory to this directory ( findme/tests )
###  2) Press::     CTRL + SHIFT + L   to load current package changes into memory before running
###  3) Source this file
###
###  OR  JUST RUN:
###
###                 setwd(appgen::tests_path());  devtools::load_all(".");   source("testthat.R")
###
###  OR FOR A COVERAGE REPORT RUN:
###
###                 setwd(appgen::tests_path());  devtools::load_all(".");   covr::report(covr::package_coverage(quiet = FALSE, clean = FALSE))
###
###+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

library(testthat)
library(findme)
library(shiny)
library(shinygen)
#library(appgen)

tryCatch({
    # warn = 2 non-normal: force error condition if any warnings show up
    # warn = 1 log warnings immediately
    # warn = 0 is default log-only at end of method
    options(warn = 2)

    test_check("findme")

}, finally = {
    options(warn = 0)
})

